// Code Block Component
document.addEventListener('DOMContentLoaded', function() {
  // Tab switching for code blocks
  const tabButtons = document.querySelectorAll('.code-block-tab');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const codeBlock = button.closest('.code-block');
      const tabName = button.getAttribute('data-tab');
      
      // Update active tab
      codeBlock.querySelectorAll('.code-block-tab').forEach(tab => {
        tab.classList.remove('active');
      });
      button.classList.add('active');
      
      // Update active content
      codeBlock.querySelectorAll('.code-block-content').forEach(content => {
        content.classList.remove('active');
      });
      codeBlock.querySelector(`.code-block-content[data-tab="${tabName}"]`).classList.add('active');
    });
  });
  
  // Copy code functionality
  const copyButtons = document.querySelectorAll('.copy-button');
  
  copyButtons.forEach(button => {
    button.addEventListener('click', () => {
      const codeBlock = button.closest('.code-block');
      const activeContent = codeBlock.querySelector('.code-block-content.active');
      const code = activeContent.querySelector('code').innerText;
      
      navigator.clipboard.writeText(code).then(() => {
        button.textContent = 'Copied!';
        setTimeout(() => {
          button.textContent = 'Copy';
        }, 2000);
      });
    });
  });

  // Component Tabs
  const componentTabButtons = document.querySelectorAll('.tab-button');
  
  componentTabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabName = button.getAttribute('data-tab');
      const tabsContainer = button.closest('.tabs');
      
      // Update active tab button
      tabsContainer.querySelectorAll('.tab-button').forEach(tab => {
        tab.classList.remove('active');
      });
      button.classList.add('active');
      
      // Update active content
      tabsContainer.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
      });
      tabsContainer.querySelector(`#${tabName}`).classList.add('active');
    });
  });
});
