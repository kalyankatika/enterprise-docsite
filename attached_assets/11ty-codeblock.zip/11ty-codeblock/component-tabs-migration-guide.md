# Component Tabs Migration Guide

This guide provides detailed instructions for transporting the four tabs feature from this 11ty documentation site to another 11ty site.

## Overview

The component tabs feature provides a standardized structure for component documentation with four tabs:

1. **Examples Tab**: For showcasing component variants, states, and usage examples
2. **Design Tab**: For design guidelines, use cases, and visual style information
3. **Code Tab**: For technical documentation including attributes, events, methods, and API details
4. **Accessibility Tab**: For accessibility guidelines, ARIA attributes, and WCAG compliance information

## Required Files

To implement this feature in another 11ty site, you'll need to copy these files:

1. `src/_includes/component-tabs.njk` - The Nunjucks macro for the tabs component
2. JavaScript for tab switching functionality (in `src/assets/js/main.js`)
3. CSS styles for the tabs (in `src/assets/css/style.css` or included directly in the macro)

## Step-by-Step Migration Guide

### Step 1: Copy the Component Tabs Macro

Create a file named `component-tabs.njk` in your target site's includes directory (typically `_includes/`) with the following content:

```njk
{% macro componentTabs(title, tabContent) %}
<h1>{{ title }}</h1>

<div class="tabs">
  <div class="tab-header">
    <button class="tab-button active" data-tab="examples">Examples</button>
    <button class="tab-button" data-tab="design">Design</button>
    <button class="tab-button" data-tab="code">Code</button>
    <button class="tab-button" data-tab="accessibility">Accessibility</button>
  </div>

  <div class="tab-content active" id="examples">
    {% if tabContent.examples %}
      {{ tabContent.examples | safe }}
    {% else %}
      <!-- Examples tab content goes here -->
      <p>Examples content placeholder</p>
    {% endif %}
  </div>

  <div class="tab-content" id="design">
    {% if tabContent.design %}
      {{ tabContent.design | safe }}
    {% else %}
      <!-- Design tab content goes here -->
      <p>Design content placeholder</p>
    {% endif %}
  </div>

  <div class="tab-content" id="code">
    {% if tabContent.code %}
      {{ tabContent.code | safe }}
    {% else %}
      <!-- Code tab content goes here -->
      <p>Code content placeholder</p>
    {% endif %}
  </div>

  <div class="tab-content" id="accessibility">
    {% if tabContent.accessibility %}
      {{ tabContent.accessibility | safe }}
    {% else %}
      <!-- Accessibility tab content goes here -->
      <p>Accessibility content placeholder</p>
    {% endif %}
  </div>
</div>

<style>
  /* Tab styles */
  .tabs {
    margin: 2rem 0;
    border: 1px solid #e5e7eb;
    border-radius: 0.5rem;
    overflow: hidden;
  }
  
  .tab-header {
    display: flex;
    border-bottom: 1px solid #e5e7eb;
    background-color: #ffffff;
    padding: 0;
  }
  
  .tab-button {
    padding: 1rem 1.5rem;
    background: none;
    border: none;
    cursor: pointer;
    font-weight: 600;
    color: #000000;
    border-bottom: 3px solid transparent;
    transition: all 0.2s ease;
    margin: 0;
    position: relative;
    border-radius: 0px;
  }
  
  .tab-button:hover {
    background-color: #f5f5f5;
    border-bottom-color: #000000;
  }
  
  .tab-button.active {
    color: #000000;
    border-bottom-color: #368727;
    font-weight: 700;
  }
  
  .tab-content {
    display: none;
    padding: 1.5rem;
  }
  
  .tab-content.active {
    display: block;
  }

  /* Example styles */
  .example {
    margin: 1rem 0;
    padding: 1rem;
    border: 1px solid #e5e7eb;
    border-radius: 0.25rem;
    background-color: #f9fafb;
  }

  /* Alert styles */
  .alert {
    background-color: #fff3cd;
    border-color: #ffecb5;
    color: #664d03;
    padding: 1rem;
    margin: 1rem 0;
    border-radius: 0.25rem;
  }
</style>
{% endmacro %}
```

### Step 2: Add JavaScript for Tab Functionality

Add the following JavaScript to your site's main JavaScript file (or create a new one):

```javascript
// Component Tabs
document.addEventListener('DOMContentLoaded', function() {
  const componentTabButtons = document.querySelectorAll('.tab-button');
  
  componentTabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabName = button.getAttribute('data-tab');
      const tabsContainer = button.closest('.tabs');
      
      // Update active tab button
      tabsContainer.querySelectorAll('.tab-button').forEach(tab => {
        tab.classList.remove('active');
      });
      button.classList.add('active');
      
      // Update active content
      tabsContainer.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
      });
      tabsContainer.querySelector(`#${tabName}`).classList.add('active');
    });
  });
});
```

### Step 3: Add CSS Styles (Optional)

If you prefer to keep the styles in a separate CSS file rather than inline in the macro, add these styles to your main CSS file:

```css
/* Tab styles */
.tabs {
  margin: 2rem 0;
  border: 1px solid #e5e7eb;
  border-radius: 0.5rem;
  overflow: hidden;
}

.tab-header {
  display: flex;
  border-bottom: 1px solid #e5e7eb;
  background-color: #ffffff;
  padding: 0;
}

.tab-button {
  padding: 1rem 1.5rem;
  background: none;
  border: none;
  cursor: pointer;
  font-weight: 600;
  color: #000000;
  border-bottom: 3px solid transparent;
  transition: all 0.2s ease;
  margin: 0;
  position: relative;
  border-radius: 0px;
}

.tab-button:hover {
  background-color: #f5f5f5;
  border-bottom-color: #000000;
}

.tab-button.active {
  color: #000000;
  border-bottom-color: #368727;
  font-weight: 700;
}

.tab-content {
  display: none;
  padding: 1.5rem;
}

.tab-content.active {
  display: block;
}

/* Example styles */
.example {
  margin: 1rem 0;
  padding: 1rem;
  border: 1px solid #e5e7eb;
  border-radius: 0.25rem;
  background-color: #f9fafb;
}

/* Alert styles */
.alert {
  background-color: #fff3cd;
  border-color: #ffecb5;
  color: #664d03;
  padding: 1rem;
  margin: 1rem 0;
  border-radius: 0.25rem;
}
```

### Step 4: Using the Component Tabs in Your Content Files

Now you can use the component tabs in your Markdown or Nunjucks files. Here's an example:

```markdown
---
layout: base.njk
title: My Component - Documentation Site
permalink: /my-component/
---

{% from "component-tabs.njk" import componentTabs %}

{% set examplesContent %}
## Overview

My Component provides [description of what the component does].

## Basic Usage

```html
<my-component>Example content</my-component>
```

## Examples

### Default Example

<div class="example">
  <my-component>Example content</my-component>
</div>

Code example:
```html
<my-component>Example content</my-component>
```
{% endset %}

{% set designContent %}
## Design Guidelines

### Use when

- [Use case 1]
- [Use case 2]
- [Use case 3]

### Don't use when

- [Avoid case 1]
- [Avoid case 2]

### Visual style

[Design information here]
{% endset %}

{% set codeContent %}
## Code Documentation

### Attributes

| Attribute | Type | Default | Description |
| --------- | ---- | ------- | ----------- |
| `attribute-1` | string | `""` | Description of attribute 1 |
| `attribute-2` | boolean | `false` | Description of attribute 2 |

### Events

| Event | Description |
| ----- | ----------- |
| `event-1` | Description of event 1 |
| `event-2` | Description of event 2 |

### Methods

| Method | Description |
| ------ | ----------- |
| `method1()` | Description of method 1 |
| `method2(param)` | Description of method 2 |
{% endset %}

{% set accessibilityContent %}
## Accessibility

### ARIA Attributes

- `role="[appropriate role]"` - [Description]
- `aria-[attribute]` - [Description]

### Keyboard Navigation

| Key | Function |
| --- | -------- |
| `Tab` | [Description] |
| `Enter` | [Description] |
| `Space` | [Description] |

### WCAG Compliance

This component satisfies the following WCAG success criteria:

- 1.4.3 Contrast (Minimum)
- 2.1.1 Keyboard
- 4.1.2 Name, Role, Value
{% endset %}

{{ componentTabs("My Component", {
  examples: examplesContent,
  design: designContent,
  code: codeContent,
  accessibility: accessibilityContent
}) }}
```

## Integrating with Code Block Feature

If you also want to include the code block feature with tabs and copy functionality, you'll need to:

1. Copy the `code-block.njk` macro
2. Add the corresponding JavaScript and CSS
3. Import and use it in your component documentation

### Code Block Macro

```njk
{% macro codeBlock(code, language1, code2) %}
<div class="code-block">
  <div class="code-block-header">
    <div class="code-block-tabs">
      {% if code2 %}
      <div class="code-block-tab active" data-tab="tab1">{{ language1 | default("HTML") }}</div>
      <div class="code-block-tab" data-tab="tab2">{{ language2 | default("JavaScript") }}</div>
      {% else %}
      <div class="code-block-tab active" data-tab="tab1">{{ language1 | default("Code") }}</div>
      {% endif %}
    </div>
    <div class="code-block-actions">
      <button class="copy-button" title="Copy code">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
        </svg>
      </button>
    </div>
  </div>
  <div class="code-block-content">
    <div class="code-block-content active" data-tab="tab1">
      <pre class="language-{{ language1 | default('html') }}"><code class="language-{{ language1 | default('html') }}">{{ code | safe }}</code></pre>
    </div>
    {% if code2 %}
    <div class="code-block-content" data-tab="tab2">
      <pre class="language-{{ language2 | default('javascript') }}"><code class="language-{{ language2 | default('javascript') }}">{{ code2 | safe }}</code></pre>
    </div>
    {% endif %}
  </div>
</div>
{% endmacro %}
```

## Customization Options

### Changing Tab Names

If you want to change the tab names, modify the `data-tab` attributes and corresponding IDs in the component-tabs.njk file:

```html
<div class="tab-header">
  <button class="tab-button active" data-tab="tab1">Tab 1 Name</button>
  <button class="tab-button" data-tab="tab2">Tab 2 Name</button>
  <button class="tab-button" data-tab="tab3">Tab 3 Name</button>
  <button class="tab-button" data-tab="tab4">Tab 4 Name</button>
</div>

<div class="tab-content active" id="tab1">
  <!-- Tab 1 content -->
</div>

<div class="tab-content" id="tab2">
  <!-- Tab 2 content -->
</div>

<div class="tab-content" id="tab3">
  <!-- Tab 3 content -->
</div>

<div class="tab-content" id="tab4">
  <!-- Tab 4 content -->
</div>
```

### Changing Colors

To change the active tab indicator color, modify the CSS variable or directly change the border color:

```css
.tab-button.active {
  border-bottom-color: #YOUR_COLOR_HERE; /* Change from #368727 to your preferred color */
}
```

## Troubleshooting

### Tabs Not Switching

If the tabs aren't switching correctly:

1. Check that the JavaScript is properly loaded
2. Verify that the `data-tab` attributes match the corresponding content IDs
3. Check the browser console for any JavaScript errors

### Styling Issues

If the tabs don't look right:

1. Make sure the CSS is properly loaded
2. Check for any CSS conflicts with your existing styles
3. Use browser developer tools to inspect the elements and identify styling issues

## Conclusion

This component tabs system provides a standardized structure for documenting components with a consistent user experience. By following this guide, you can easily transport this feature to any 11ty documentation site.
