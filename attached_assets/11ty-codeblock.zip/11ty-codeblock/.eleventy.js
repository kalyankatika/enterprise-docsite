const markdownIt = require("markdown-it");
const markdownItPrism = require("markdown-it-prism");

module.exports = function(eleventyConfig) {
  // Copy assets directory to output
  eleventyConfig.addPassthroughCopy("src/assets");
  
  // Configure Markdown processing
  const markdownLibrary = markdownIt({
    html: true,
    breaks: true,
    linkify: true
  }).use(markdownItPrism);
  
  eleventyConfig.setLibrary("md", markdownLibrary);
  
  return {
    dir: {
      input: "src",
      output: "_site",
      includes: "_includes",
      layouts: "_layouts"
    },
    templateFormats: ["md", "njk", "html"],
    markdownTemplateEngine: "njk",
    htmlTemplateEngine: "njk",
    dataTemplateEngine: "njk"
  };
};
