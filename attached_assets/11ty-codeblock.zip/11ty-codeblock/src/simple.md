---
layout: base.njk
title: Simple Page
permalink: /simple/
---

# Simple Page

This is a very simple page with no macros or complex components.

## Hello World

Just some basic markdown content to verify the site is working correctly.

- Item 1
- Item 2
- Item 3

```html
<p>A simple HTML example</p>
```
