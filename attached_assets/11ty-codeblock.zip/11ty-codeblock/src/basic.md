---
permalink: /basic/
---

# Basic Page

This is a very basic page with no layout or includes.

## Hello World

Just some basic markdown content.
