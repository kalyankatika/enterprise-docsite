---
layout: base.njk
title: Components - 11ty Documentation Site
permalink: /components/
---

{% from "code-block.njk" import codeBlock %}

# Components

This page lists all the components available in our documentation site.

## Available Components

- [Button Component](/button/) - A versatile button component with multiple variants and states
- [Toggle Switch Component](/toggle-switch/) - A toggle switch component for enabling/disabling features
- [Component Template](/component-template/) - A template for creating new components

## Code Block Component

The code block component allows you to display code in multiple languages with tabs and a copy button.

### Basic Usage

{{ codeBlock(
  'class ExampleComponent extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          padding: 16px;
        }
        h2 {
          margin-top: 0;
          color: #2563eb;
        }
        button {
          background-color: #2563eb;
          color: white;
          border: none;
          padding: 0.5rem 1rem;
          border-radius: 0.25rem;
          cursor: pointer;
          font-weight: bold;
        }
        button:hover {
          background-color: #1e40af;
        }
      </style>
      <div>
        <h2>Example Component</h2>
        <p>This is an example component to demonstrate the code block.</p>
        <button id="example-button">Click me!</button>
      </div>
    `;
    
    this.button = this.shadowRoot.querySelector("#example-button");
    this.button.addEventListener("click", () => {
      alert("Button clicked!");
    });
  }
}
customElements.define("example-component", ExampleComponent);',
  '<div class="example-component">
  <h2 class="example-title">Example Component</h2>
  <p class="example-description">This is an example component to demonstrate the code block.</p>
  <button class="example-button">Click me!</button>
</div>'
) }}

## How It Works

The code block component uses JavaScript to handle tab switching and copy functionality. The component is built with the following features:

1. **Tabs**: Switch between different code languages
2. **Copy Button**: Copy the code to clipboard with a single click
3. **Syntax Highlighting**: Powered by Prism.js for beautiful code highlighting

## Implementation

To use the code block component in your own pages, you can import the macro and use it like this:

```njk
{% raw %}
{% from "code-block.njk" import codeBlock %}

{{ codeBlock(
  'class MyComponent extends HTMLElement {
  // Your Web Component code here
}
customElements.define("my-component", MyComponent);',
  '<div>Your HTML code here</div>'
) }}
{% endraw %}
```

## Live Example

Here's a live example of the component in action:

<div class="example-component">
  <h2 class="example-title">Example Component</h2>
  <p class="example-description">This is an example component to demonstrate the code block.</p>
  <button class="example-button" onclick="alert('Button clicked!')">Click me!</button>
</div>

<script>
  // This script is just for the live example
  document.addEventListener("DOMContentLoaded", () => {
    const button = document.querySelector(".example-button");
    
    // The click handler is already set with the onclick attribute
    console.log("Example component initialized");
  });
</script>

<style>
  .example-component {
    border: 1px solid #e5e7eb;
    border-radius: 0.5rem;
    padding: 1.5rem;
    margin: 2rem 0;
    background-color: #f9fafb;
  }
  
  .example-title {
    margin-top: 0;
    color: #2563eb;
  }
  
  .example-button {
    background-color: #2563eb;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 0.25rem;
    cursor: pointer;
    font-weight: bold;
  }
  
  .example-button:hover {
    background-color: #1e40af;
  }
</style>
