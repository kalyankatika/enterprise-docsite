---
layout: base.njk
title: 11ty Documentation Site
---

# Welcome to the 11ty Documentation Site

This is a simple documentation site built with 11ty.

## Components

- [Button](/button/) - The button component documentation
- [Toggle Switch](/toggle-switch/) - A toggle switch component using the component-tabs template
- [Component Template](/component-template/) - A template for creating new components

## Other Pages

- [Simple Page](/simple/) - A very basic page with no macros
- [Example Component](/example/) - A slightly more complex example
- [Basic Page](/basic/) - A minimal page with no layout

## Features

- Markdown-based documentation
- Syntax highlighting with Prism.js
- Component tabs for organizing documentation
- Responsive design
