---
layout: base.njk
title: Example Component - 11ty Documentation Site
permalink: /example/
---

# Example Component

This is a simple example page to demonstrate the site is working.

## Code Example

```html
<div class="example">
  <h2>Hello World</h2>
  <p>This is a sample component</p>
</div>
```

## More Information

This page doesn't use any complex components or macros, just to ensure the site can build and run properly.
