---
layout: base.njk
title: Component Template - 11ty Documentation Site
permalink: /component-template/
---

{% from "code-block.njk" import codeBlock %}
{% from "component-tabs.njk" import componentTabs %}

{% set examplesContent %}
## Overview

This is the examples section of the component. Here you can provide an overview of the component and its usage.

## Installation

```bash
npm install @your-package/component
```

## Basic Usage

```html
<your-component>Basic usage example</your-component>
```

## Examples

### Example 1

<div class="example">
  Example 1 content goes here
</div>

Code example:
```html
<your-component variant="primary">Example 1</your-component>
```

### Example 2

<div class="example">
  Example 2 content goes here
</div>

Code example:
```html
<your-component variant="secondary">Example 2</your-component>
```

### Example with Alert

<div class="example alert">
  <strong>Note:</strong> This is an important alert about the component.
</div>
{% endset %}

{% set designContent %}
## Design Guidelines

### Use when

- Use case 1
- Use case 2
- Use case 3

### Don't use when

- Don't use case 1
- Don't use case 2

### Visual style

#### Variations

Describe the visual variations of the component.

#### Spacing and layout

Describe spacing and layout considerations.

### Behavior

Describe how the component behaves in different states and interactions.

### Content guidelines

Provide guidelines for the content within the component.
{% endset %}

{% set codeContent %}
## Code Documentation

### Attributes

| Attribute | Type | Default | Description |
| --------- | ---- | ------- | ----------- |
| `variant` | string | `primary` | The variant of the component |
| `size` | string | `medium` | The size of the component |
| `disabled` | boolean | `false` | Whether the component is disabled |

### Events

| Event | Description |
| ----- | ----------- |
| `click` | Fired when the component is clicked |
| `focus` | Fired when the component receives focus |

### Methods

| Method | Description |
| ------ | ----------- |
| `focus()` | Focuses the component |
| `reset()` | Resets the component to its initial state |

### CSS Variables

| Variable | Default | Description |
| -------- | ------- | ----------- |
| `--component-color` | `#368727` | The primary color of the component |
| `--component-background` | `#ffffff` | The background color of the component |
{% endset %}

{% set accessibilityContent %}
## Accessibility

### ARIA Attributes

Describe the ARIA attributes used by the component.

### Keyboard Navigation

Describe how to navigate the component using a keyboard.

### Screen Reader Support

Describe how the component works with screen readers.

### WCAG Compliance

This component satisfies the following WCAG success criteria:

#### 1.4.3 Contrast (Minimum) (AA)
Text and images of text have a contrast ratio of at least 4.5:1.

#### 2.1.1 Keyboard (A)
All functionality is operable through a keyboard interface.

#### 2.4.7 Focus Visible (AA)
Keyboard focus indicator is visible.
{% endset %}

{{ componentTabs("Component Template", {
  examples: examplesContent,
  design: designContent,
  code: codeContent,
  accessibility: accessibilityContent
}) }}
