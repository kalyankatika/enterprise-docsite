---
layout: base.njk
title: Button Component - 11ty Documentation Site
permalink: /button/
---

{% from "code-block.njk" import codeBlock %}

# Button Component

Buttons are interactive elements that allow users to trigger actions or navigate to different parts of an application.

<div class="tabs">
  <div class="tab-header">
    <button class="tab-button active" data-tab="examples">Examples</button>
    <button class="tab-button" data-tab="design">Design</button>
    <button class="tab-button" data-tab="code">Code</button>
    <button class="tab-button" data-tab="accessibility">Accessibility</button>
  </div>

  <div class="tab-content active" id="examples">
    <h2>Examples</h2>
    
    <h3>Button Variants</h3>
    
    <h4>Primary Button</h4>
    <p>Use primary buttons for the main action on a page or in a section.</p>
    <div class="example">
      <button class="button button--primary">Primary Button</button>
    </div>
    
    {{ codeBlock(
      'class PrimaryButton extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: inline-block;
        }
        button {
          background-color: #2563eb;
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 0.25rem;
          font-weight: 600;
          font-size: 1rem;
          cursor: pointer;
          transition: background-color 0.2s;
        }
        button:hover {
          background-color: #1d4ed8;
        }
        button:focus {
          outline: 2px solid #3b82f6;
          outline-offset: 2px;
        }
      </style>
      <button><slot>Button</slot></button>
    `;
  }
}
customElements.define("primary-button", PrimaryButton);',
      '<button class="button button--primary">Primary Button</button>'
    ) }}
    
    <h4>Secondary Button</h4>
    <p>Use secondary buttons for alternative actions that are not the primary focus.</p>
    <div class="example">
      <button class="button button--secondary">Secondary Button</button>
    </div>
    
    {{ codeBlock(
      'class SecondaryButton extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: inline-block;
        }
        button {
          background-color: white;
          color: #2563eb;
          border: 1px solid #2563eb;
          padding: 0.75rem 1.5rem;
          border-radius: 0.25rem;
          font-weight: 600;
          font-size: 1rem;
          cursor: pointer;
          transition: background-color 0.2s;
        }
        button:hover {
          background-color: #f0f9ff;
        }
        button:focus {
          outline: 2px solid #3b82f6;
          outline-offset: 2px;
        }
      </style>
      <button><slot>Button</slot></button>
    `;
  }
}
customElements.define("secondary-button", SecondaryButton);',
      '<button class="button button--secondary">Secondary Button</button>'
    ) }}
    
    <h4>Tertiary Button</h4>
    <p>Use tertiary buttons for less important actions or in space-constrained areas.</p>
    <div class="example">
      <button class="button button--tertiary">Tertiary Button</button>
    </div>
    
    {{ codeBlock(
      'class TertiaryButton extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: inline-block;
        }
        button {
          background-color: transparent;
          color: #2563eb;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 0.25rem;
          font-weight: 600;
          font-size: 1rem;
          cursor: pointer;
          transition: background-color 0.2s;
        }
        button:hover {
          background-color: #f0f9ff;
        }
        button:focus {
          outline: 2px solid #3b82f6;
          outline-offset: 2px;
        }
      </style>
      <button><slot>Button</slot></button>
    `;
  }
}
customElements.define("tertiary-button", TertiaryButton);',
      '<button class="button button--tertiary">Tertiary Button</button>'
    ) }}
    
    <h4>Invitation Button</h4>
    <p>Use invitation buttons to encourage users to take an action.</p>
    <div class="example">
      <button class="button button--invitation">Get Started</button>
    </div>
    
    {{ codeBlock(
      'class InvitationButton extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: inline-block;
        }
        button {
          background-color: #059669;
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 0.25rem;
          font-weight: 600;
          font-size: 1rem;
          cursor: pointer;
          transition: background-color 0.2s;
        }
        button:hover {
          background-color: #047857;
        }
        button:focus {
          outline: 2px solid #10b981;
          outline-offset: 2px;
        }
      </style>
      <button><slot>Get Started</slot></button>
    `;
  }
}
customElements.define("invitation-button", InvitationButton);',
      '<button class="button button--invitation">Get Started</button>'
    ) }}
    
    <h3>Button States</h3>
    
    <h4>Disabled Button</h4>
    <p>Use disabled buttons to indicate that an action is not currently available.</p>
    <div class="example">
      <button class="button button--primary" disabled>Disabled Button</button>
    </div>
    
    {{ codeBlock(
      'class DisabledButton extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: inline-block;
        }
        button {
          background-color: #94a3b8;
          color: #e2e8f0;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 0.25rem;
          font-weight: 600;
          font-size: 1rem;
          cursor: not-allowed;
          opacity: 0.7;
        }
      </style>
      <button disabled><slot>Disabled Button</slot></button>
    `;
  }
}
customElements.define("disabled-button", DisabledButton);',
      '<button class="button button--primary" disabled>Disabled Button</button>'
    ) }}
    
    <h4>Loading Button</h4>
    <p>Use loading buttons to indicate that an action is in progress.</p>
    <div class="example">
      <button class="button button--primary button--loading">
        <span class="button__spinner"></span>
        Loading...
      </button>
    </div>
    
    {{ codeBlock(
      'class LoadingButton extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: inline-block;
        }
        button {
          background-color: #2563eb;
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 0.25rem;
          font-weight: 600;
          font-size: 1rem;
          cursor: wait;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        .spinner {
          width: 1rem;
          height: 1rem;
          border: 2px solid rgba(255, 255, 255, 0.3);
          border-radius: 50%;
          border-top-color: white;
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      </style>
      <button>
        <div class="spinner"></div>
        <slot>Loading...</slot>
      </button>
    `;
  }
}
customElements.define("loading-button", LoadingButton);',
      '<button class="button button--primary button--loading">
  <span class="button__spinner"></span>
  Loading...
</button>'
    ) }}
    
    <h3>Button with Icon</h3>
    <p>Add icons to buttons to enhance visual communication.</p>
    <div class="example">
      <button class="button button--primary">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M5 12h14"></path>
          <path d="M12 5l7 7-7 7"></path>
        </svg>
        Continue
      </button>
    </div>
    
    {{ codeBlock(
      'class IconButton extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: inline-block;
        }
        button {
          background-color: #2563eb;
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 0.25rem;
          font-weight: 600;
          font-size: 1rem;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        button:hover {
          background-color: #1d4ed8;
        }
        button:focus {
          outline: 2px solid #3b82f6;
          outline-offset: 2px;
        }
        svg {
          width: 1rem;
          height: 1rem;
        }
      </style>
      <button>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M5 12h14"></path>
          <path d="M12 5l7 7-7 7"></path>
        </svg>
        <slot>Continue</slot>
      </button>
    `;
  }
}
customElements.define("icon-button", IconButton);',
      '<button class="button button--primary">
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M5 12h14"></path>
    <path d="M12 5l7 7-7 7"></path>
  </svg>
  Continue
</button>'
    ) }}
  </div>

  <div class="tab-content" id="design">
    <h2>Design Guidelines</h2>
    
    <h3>When to Use</h3>
    <p>Buttons should be used for important actions that users need to take. Use buttons for:</p>
    <ul>
      <li>Form submissions</li>
      <li>Triggering modals or dialogs</li>
      <li>Initiating a process</li>
      <li>Saving or confirming actions</li>
    </ul>
    
    <h3>Button Hierarchy</h3>
    <p>Establish a clear hierarchy of buttons to guide users through the interface:</p>
    <ul>
      <li><strong>Primary buttons</strong>: Use for the main action on a page or in a section.</li>
      <li><strong>Secondary buttons</strong>: Use for alternative actions that are not the primary focus.</li>
      <li><strong>Tertiary buttons</strong>: Use for less important actions or in space-constrained areas.</li>
    </ul>
    
    <h3>Visual Style</h3>
    <p>Buttons should be visually distinct from other elements and clearly communicate their purpose:</p>
    <ul>
      <li>Use consistent padding and sizing</li>
      <li>Maintain adequate spacing between buttons</li>
      <li>Use color to indicate hierarchy and importance</li>
      <li>Provide clear hover and focus states</li>
    </ul>
    
    <h3>Button Text</h3>
    <p>Button text should be clear, concise, and action-oriented:</p>
    <ul>
      <li>Use verbs that describe the action (e.g., "Save", "Submit", "Cancel")</li>
      <li>Keep text short and to the point</li>
      <li>Be consistent with terminology across the interface</li>
      <li>Avoid vague terms like "Click Here" or "Go"</li>
    </ul>
    
    <h3>Button Spacing</h3>
    <p>Proper spacing ensures buttons are easy to interact with and visually organized:</p>
    <ul>
      <li>Maintain at least 8px spacing between adjacent buttons</li>
      <li>Group related buttons together</li>
      <li>For mobile interfaces, consider stacking buttons vertically</li>
    </ul>
    
    <h3>Button Grouping</h3>
    <p>When multiple buttons appear together, follow these guidelines:</p>
    <ul>
      <li>Place the primary action on the right (or at the bottom for vertical layouts)</li>
      <li>Group related actions together</li>
      <li>Limit the number of buttons in a single group to avoid overwhelming users</li>
    </ul>
  </div>

  <div class="tab-content" id="code">
    <h2>Implementation</h2>
    
    <h3>Installation</h3>
    <p>To use the button component in your project, include the following files:</p>
    
    <pre class="language-html"><code class="language-html">&lt;link rel="stylesheet" href="/assets/css/components/button.css"&gt;
&lt;script src="/assets/js/components/button.js"&gt;&lt;/script&gt;</code></pre>
    
    <h3>Basic Usage</h3>
    <p>The button component can be used as a web component or with HTML classes.</p>
    
    {{ codeBlock(
      '<custom-button variant="primary">Click Me</custom-button>',
      '<button class="button button--primary">Click Me</button>'
    ) }}
    
    <h3>Attributes</h3>
    <p>The button component supports the following attributes:</p>
    
    <table class="attributes-table">
      <thead>
        <tr>
          <th>Attribute</th>
          <th>Type</th>
          <th>Default</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><code>variant</code></td>
          <td>String</td>
          <td><code>primary</code></td>
          <td>Button style variant. Options: <code>primary</code>, <code>secondary</code>, <code>tertiary</code>, <code>invitation</code></td>
        </tr>
        <tr>
          <td><code>disabled</code></td>
          <td>Boolean</td>
          <td><code>false</code></td>
          <td>Whether the button is disabled</td>
        </tr>
        <tr>
          <td><code>loading</code></td>
          <td>Boolean</td>
          <td><code>false</code></td>
          <td>Whether the button is in a loading state</td>
        </tr>
        <tr>
          <td><code>icon</code></td>
          <td>String</td>
          <td><code>null</code></td>
          <td>Icon name to display in the button</td>
        </tr>
        <tr>
          <td><code>icon-position</code></td>
          <td>String</td>
          <td><code>left</code></td>
          <td>Position of the icon. Options: <code>left</code>, <code>right</code></td>
        </tr>
      </tbody>
    </table>
    
    <h3>Events</h3>
    <p>The button component emits the following events:</p>
    
    <table class="events-table">
      <thead>
        <tr>
          <th>Event</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><code>click</code></td>
          <td>Fired when the button is clicked</td>
        </tr>
        <tr>
          <td><code>focus</code></td>
          <td>Fired when the button receives focus</td>
        </tr>
        <tr>
          <td><code>blur</code></td>
          <td>Fired when the button loses focus</td>
        </tr>
      </tbody>
    </table>
    
    <h3>Examples with Native Attributes</h3>
    <p>The button component supports all native button attributes:</p>
    
    {{ codeBlock(
      '<custom-button 
  variant="primary" 
  id="submit-button"
  aria-label="Submit form"
  data-action="submit"
  onclick="handleSubmit(event)">
  Submit
</custom-button>',
      '<button 
  class="button button--primary" 
  id="submit-button"
  aria-label="Submit form"
  data-action="submit"
  onclick="handleSubmit(event)">
  Submit
</button>'
    ) }}
    
    <h3>JavaScript API</h3>
    <p>You can also interact with the button component programmatically:</p>
    
    {{ codeBlock(
      'const button = document.querySelector("custom-button");

// Set properties
button.variant = "secondary";
button.disabled = true;
button.loading = true;

// Listen for events
button.addEventListener("click", (event) => {
  console.log("Button clicked!");
});

// Methods
button.focus();
button.click();',
      'const button = document.querySelector(".button");

// Set properties
button.classList.remove("button--primary");
button.classList.add("button--secondary");
button.disabled = true;
button.classList.add("button--loading");

// Listen for events
button.addEventListener("click", (event) => {
  console.log("Button clicked!");
});

// Methods
button.focus();
button.click();'
    ) }}
  </div>

  <div class="tab-content" id="accessibility">
    <h2>Accessibility</h2>
    
    <h3>ARIA Attributes</h3>
    <p>Ensure buttons are accessible by using appropriate ARIA attributes:</p>
    
    {{ codeBlock(
      '<custom-button 
  variant="primary" 
  aria-label="Submit form"
  aria-describedby="submit-description">
  Submit
</custom-button>

<div id="submit-description" class="sr-only">
  This will submit your application form
</div>',
      '<button 
  class="button button--primary" 
  aria-label="Submit form"
  aria-describedby="submit-description">
  Submit
</button>

<div id="submit-description" class="sr-only">
  This will submit your application form
</div>'
    ) }}
    
    <h3>Keyboard Navigation</h3>
    <p>Ensure buttons are keyboard accessible:</p>
    <ul>
      <li>Buttons should be focusable with the <kbd>Tab</kbd> key</li>
      <li>Buttons should be activatable with the <kbd>Enter</kbd> or <kbd>Space</kbd> key</li>
      <li>Focus states should be clearly visible</li>
    </ul>
    
    <h3>Icon-only Buttons</h3>
    <p>When using buttons with only icons, always include an accessible name:</p>
    
    {{ codeBlock(
      '<custom-button 
  variant="tertiary" 
  aria-label="Close dialog">
  <svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <line x1="18" y1="6" x2="6" y2="18"></line>
    <line x1="6" y1="6" x2="18" y2="18"></line>
  </svg>
</custom-button>',
      '<button 
  class="button button--tertiary" 
  aria-label="Close dialog">
  <svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
    <line x1="18" y1="6" x2="6" y2="18"></line>
    <line x1="6" y1="6" x2="18" y2="18"></line>
  </svg>
</button>'
    ) }}
    
    <h3>Color Contrast</h3>
    <p>Ensure buttons have sufficient color contrast:</p>
    <ul>
      <li>Text color should have a contrast ratio of at least 4.5:1 against the background</li>
      <li>Focus indicators should have a contrast ratio of at least 3:1 against adjacent colors</li>
      <li>Do not rely on color alone to convey information</li>
    </ul>
    
    <h3>Button vs. Link</h3>
    <p>Use buttons for actions and links for navigation:</p>
    <ul>
      <li>Use <code>&lt;button&gt;</code> elements for actions that change something on the current page</li>
      <li>Use <code>&lt;a&gt;</code> elements for navigating to a new page or a different part of the current page</li>
      <li>Never use a <code>&lt;div&gt;</code> or <code>&lt;span&gt;</code> as a button</li>
    </ul>
    
    <h3>Accessible Examples</h3>
    
    <h4>Loading State</h4>
    <p>Communicate loading state to screen readers:</p>
    
    {{ codeBlock(
      '<custom-button 
  variant="primary" 
  loading
  aria-busy="true"
  aria-live="polite">
  <span class="button__spinner" aria-hidden="true"></span>
  <span class="button__text">Loading...</span>
</custom-button>',
      '<button 
  class="button button--primary button--loading" 
  aria-busy="true"
  aria-live="polite">
  <span class="button__spinner" aria-hidden="true"></span>
  <span class="button__text">Loading...</span>
</button>'
    ) }}
    
    <h4>Disabled State</h4>
    <p>Properly communicate disabled state:</p>
    
    {{ codeBlock(
      '<custom-button 
  variant="primary" 
  disabled
  aria-disabled="true">
  Submit
</custom-button>',
      '<button 
  class="button button--primary" 
  disabled
  aria-disabled="true">
  Submit
</button>'
    ) }}
  </div>
</div>

<style>
  /* Example styles */
  .example {
    border: 1px solid #e5e7eb;
    border-radius: 0.5rem;
    padding: 1.5rem;
    margin: 1rem 0;
    background-color: #f9fafb;
    display: flex;
    justify-content: center;
  }
  
  /* Button styles */
  .button {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    border-radius: 0.25rem;
    font-weight: 600;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.2s;
  }
  
  .button--primary {
    background-color: #2563eb;
    color: white;
    border: none;
  }
  
  .button--primary:hover {
    background-color: #1d4ed8;
  }
  
  .button--secondary {
    background-color: white;
    color: #2563eb;
    border: 1px solid #2563eb;
  }
  
  .button--secondary:hover {
    background-color: #f0f9ff;
  }
  
  .button--tertiary {
    background-color: transparent;
    color: #2563eb;
    border: none;
  }
  
  .button--tertiary:hover {
    background-color: #f0f9ff;
  }
  
  .button--invitation {
    background-color: #059669;
    color: white;
    border: none;
  }
  
  .button--invitation:hover {
    background-color: #047857;
  }
  
  .button:disabled,
  .button[disabled] {
    background-color: #94a3b8;
    color: #e2e8f0;
    border: none;
    cursor: not-allowed;
    opacity: 0.7;
  }
  
  .button--loading {
    cursor: wait;
  }
  
  .button__spinner {
    display: inline-block;
    width: 1rem;
    height: 1rem;
    border: 2px solid rgba(255, 255, 255, 0.3);
    border-radius: 50%;
    border-top-color: white;
    animation: spin 1s linear infinite;
  }
  
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  
  /* Tab styles */
  .tabs {
    margin: 2rem 0;
    border: 1px solid #e5e7eb;
    border-radius: 0.5rem;
    overflow: hidden;
  }
  
  .tab-header {
    display: flex;
    border-bottom: 1px solid #e5e7eb;
    background-color: #f9fafb;
  }
  
  .tab-button {
    padding: 1rem 1.5rem;
    background: none;
    border: none;
    cursor: pointer;
    font-weight: 600;
    color: #64748b;
    border-bottom: 2px solid transparent;
  }
  
  .tab-button.active {
    color: #2563eb;
    border-bottom-color: #2563eb;
  }
  
  .tab-content {
    display: none;
    padding: 1.5rem;
  }
  
  .tab-content.active {
    display: block;
  }
  
  /* Table styles */
  .attributes-table,
  .events-table {
    width: 100%;
    border-collapse: collapse;
    margin: 1rem 0;
  }
  
  .attributes-table th,
  .attributes-table td,
  .events-table th,
  .events-table td {
    padding: 0.75rem;
    text-align: left;
    border: 1px solid #e5e7eb;
  }
  
  .attributes-table th,
  .events-table th {
    background-color: #f9fafb;
    font-weight: 600;
  }
  
  /* Screen reader only class */
  .sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border-width: 0;
  }
  
  /* Keyboard key styling */
  kbd {
    display: inline-block;
    padding: 0.1rem 0.4rem;
    font-size: 0.875rem;
    font-family: monospace;
    line-height: 1;
    color: #1f2937;
    background-color: #f3f4f6;
    border: 1px solid #d1d5db;
    border-radius: 0.25rem;
    box-shadow: 0 1px 0 rgba(0, 0, 0, 0.2);
  }
</style>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        // Remove active class from all buttons and contents
        tabButtons.forEach(btn => btn.classList.remove('active'));
        tabContents.forEach(content => content.classList.remove('active'));
        
        // Add active class to clicked button and corresponding content
        button.classList.add('active');
        const tabId = button.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');
      });
    });
  });
</script>

        tabContents.forEach(content => content.classList.remove('active'));
        
        // Add active class to clicked button and corresponding content
        button.classList.add('active');
        const tabId = button.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');
      });
    });
  });
</script>
