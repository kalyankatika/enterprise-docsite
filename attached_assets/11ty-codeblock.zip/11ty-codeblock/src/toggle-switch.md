---
layout: base.njk
title: Toggle Switch Component - 11ty Documentation Site
permalink: /toggle-switch/
---

{% from "code-block.njk" import codeBlock %}
{% from "component-tabs.njk" import componentTabs %}

{% set examplesContent %}
## Overview

The Toggle Switch component provides a visual way to toggle between two states, typically on and off. It's commonly used for enabling or disabling features, settings, or preferences.

## Installation

```bash
npm install @fmr-ap153177/apex-kit
```

## Basic Usage

```html
<eds-toggle-switch>Enable notifications</eds-toggle-switch>
```

## Examples

### Default Toggle

<div class="example">
  <eds-toggle-switch>Enable notifications</eds-toggle-switch>
</div>

Code example:
```html
<eds-toggle-switch>Enable notifications</eds-toggle-switch>
```

### Checked Toggle

<div class="example">
  <eds-toggle-switch eds-checked>Notifications enabled</eds-toggle-switch>
</div>

Code example:
```html
<eds-toggle-switch eds-checked>Notifications enabled</eds-toggle-switch>
```

### Disabled Toggle

<div class="example">
  <eds-toggle-switch eds-disabled>Disabled toggle</eds-toggle-switch>
</div>

Code example:
```html
<eds-toggle-switch eds-disabled>Disabled toggle</eds-toggle-switch>
```

### Toggle with Label Position

<div class="example">
  <eds-toggle-switch eds-label-position="left">Label on left</eds-toggle-switch>
</div>

Code example:
```html
<eds-toggle-switch eds-label-position="left">Label on left</eds-toggle-switch>
```

### Toggle with Custom Colors

<div class="example">
  <eds-toggle-switch eds-checked style="--toggle-active-color: #8A2BE2;">Custom purple</eds-toggle-switch>
</div>

Code example:
```html
<eds-toggle-switch eds-checked style="--toggle-active-color: #8A2BE2;">Custom purple</eds-toggle-switch>
```

### Toggle with Helper Text

<div class="example">
  <eds-toggle-switch eds-helper-text="This setting will enable push notifications on your device">
    Enable notifications
  </eds-toggle-switch>
</div>

Code example:
```html
<eds-toggle-switch eds-helper-text="This setting will enable push notifications on your device">
  Enable notifications
</eds-toggle-switch>
```

### Toggle with Error State

<div class="example alert">
  <eds-toggle-switch eds-error="This feature requires additional permissions">
    Enable location services
  </eds-toggle-switch>
</div>

Code example:
```html
<eds-toggle-switch eds-error="This feature requires additional permissions">
  Enable location services
</eds-toggle-switch>
```
{% endset %}

{% set designContent %}
## Design Guidelines

### Use when

- Providing immediate results when the user changes a setting
- Toggling between two opposing states (on/off, enabled/disabled)
- Settings that require a binary choice
- Applying changes immediately without requiring a submission step

### Don't use when

- The user needs to choose between more than two options (use radio buttons or a dropdown instead)
- The change requires confirmation before applying (use a checkbox and submit button instead)
- The action is not reversible (use a button with confirmation instead)
- The change doesn't take effect immediately (use a checkbox instead)

### Visual style

#### States

Toggle switches have the following states:
- **Off**: The default state, indicating the feature is disabled
- **On**: The active state, indicating the feature is enabled
- **Disabled**: When the toggle cannot be interacted with
- **Focus**: When the toggle has keyboard focus
- **Error**: When there's an issue with the toggle's state

#### Anatomy

![Toggle switch anatomy showing track, thumb, and label](../images/toggle/toggle-anatomy.png)

1. **Track**: The background element that contains the thumb
2. **Thumb**: The movable element that indicates the state
3. **Label**: Text that describes the toggle's purpose

#### Spacing and layout

- Leave at least 16px of space between multiple toggle switches
- Maintain 8px between the toggle and its label
- For mobile, ensure the touch target area is at least 44x44px

### Behavior

- Toggles should provide immediate feedback when activated
- The state change should be visually clear through movement and color
- Include a subtle animation when toggling between states
- When focused, the toggle should display a visible focus indicator

### Content guidelines

- Use clear, concise labels that describe what the toggle controls
- Frame the label in a positive way (e.g., "Enable notifications" rather than "Disable notifications")
- Be specific about what is being toggled
- Use sentence case for labels
- Optional helper text can provide additional context
{% endset %}

{% set codeContent %}
## Code Documentation

### Installation

Install the Apex Kit package which includes the Toggle Switch component:

{{ codeBlock(
  'npm install @fmr-ap153177/apex-kit',
  'bash'
) }}

### Basic Implementation

Here's how to implement a basic toggle switch:

{{ codeBlock(
  '<eds-toggle-switch>Enable notifications</eds-toggle-switch>',
  'html',
  'const toggle = document.querySelector(\'eds-toggle-switch\');
toggle.addEventListener(\'eds-change\', (event) => {
  console.log(\'Toggle changed:\', event.detail.checked);
});'
) }}

### Advanced Implementation

For more complex scenarios, you can use the toggle switch with custom styling and event handling:

{{ codeBlock(
  '<eds-toggle-switch
  eds-checked
  eds-helper-text="This setting will enable push notifications"
  eds-label-position="left"
  style="--toggle-active-color: #8A2BE2;">
  Enable notifications
</eds-toggle-switch>',
  'html',
  'class NotificationManager {
  constructor() {
    this.toggle = document.querySelector(\'eds-toggle-switch\');
    this.setupEventListeners();
    this.syncWithUserPreferences();
  }
  
  setupEventListeners() {
    this.toggle.addEventListener(\'eds-change\', this.handleToggleChange.bind(this));
  }
  
  handleToggleChange(event) {
    const isEnabled = event.detail.checked;
    if (isEnabled) {
      this.enableNotifications();
    } else {
      this.disableNotifications();
    }
  }
  
  syncWithUserPreferences() {
    const userPreferences = this.getUserPreferences();
    this.toggle.edsChecked = userPreferences.notificationsEnabled;
  }
  
  enableNotifications() {
    console.log(\'Notifications enabled\');
    // Implementation code
  }
  
  disableNotifications() {
    console.log(\'Notifications disabled\');
    // Implementation code
  }
  
  getUserPreferences() {
    // Get user preferences from storage
    return { notificationsEnabled: false };
  }
}

const notificationManager = new NotificationManager();'
) }}

### Attributes

| Attribute | Type | Default | Description |
| --------- | ---- | ------- | ----------- |
| `eds-checked` | boolean | `false` | Sets the toggle to the on position |
| `eds-disabled` | boolean | `false` | Disables the toggle switch |
| `eds-label-position` | string | `right` | Position of the label: `left` or `right` |
| `eds-helper-text` | string | -- | Additional descriptive text below the toggle |
| `eds-error` | string | -- | Error message to display when the toggle is in an error state |
| `eds-name` | string | -- | Name attribute for the internal input element |
| `eds-value` | string | -- | Value attribute for the internal input element |
| `eds-required` | boolean | `false` | Indicates if the toggle is required |
| `eds-aria-label` | string | -- | Accessible label for screen readers |

### Events

| Event | Description |
| ----- | ----------- |
| `eds-change` | Fired when the toggle state changes |
| `eds-focus` | Fired when the toggle receives focus |
| `eds-blur` | Fired when the toggle loses focus |

### Methods

| Method | Description |
| ------ | ----------- |
| `toggle()` | Toggles the switch between on and off states |
| `check()` | Sets the toggle to the on position |
| `uncheck()` | Sets the toggle to the off position |
| `focus()` | Sets focus to the toggle |

### CSS Variables

| Variable | Default | Description |
| -------- | ------- | ----------- |
| `--toggle-width` | `40px` | Width of the toggle track |
| `--toggle-height` | `24px` | Height of the toggle track |
| `--toggle-active-color` | `#368727` | Color when toggle is in the on position |
| `--toggle-inactive-color` | `#D1D5DB` | Color when toggle is in the off position |
| `--toggle-thumb-color` | `#FFFFFF` | Color of the toggle thumb |
| `--toggle-disabled-opacity` | `0.5` | Opacity when toggle is disabled |

### React Integration

If you're using React, here's how to integrate the toggle switch component:

{{ codeBlock(
  'import React, { useEffect, useRef } from \'react\';

const ToggleSwitch = ({ 
  checked = false, 
  disabled = false,
  labelPosition = \'right\',
  helperText,
  onChange,
  children
}) => {
  const toggleRef = useRef(null);
  
  useEffect(() => {
    const toggle = toggleRef.current;
    
    const handleChange = (e) => {
      if (onChange) {
        onChange(e.detail.checked);
      }
    };
    
    toggle.addEventListener(\'eds-change\', handleChange);
    
    return () => {
      toggle.removeEventListener(\'eds-change\', handleChange);
    };
  }, [onChange]);
  
  useEffect(() => {
    const toggle = toggleRef.current;
    toggle.edsChecked = checked;
  }, [checked]);
  
  return (
    <eds-toggle-switch
      ref={toggleRef}
      eds-disabled={disabled}
      eds-label-position={labelPosition}
      eds-helper-text={helperText}
    >
      {children}
    </eds-toggle-switch>
  );
};

export default ToggleSwitch;',
  'jsx',
  'import ToggleSwitch from \'./ToggleSwitch\';
import { useState } from \'react\';

function App() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  
  const handleToggleChange = (isChecked) => {
    setNotificationsEnabled(isChecked);
    console.log(`Notifications ${isChecked ? \'enabled\' : \'disabled\'}`);
  };
  
  return (
    <div className="app">
      <h1>Settings</h1>
      <ToggleSwitch
        checked={notificationsEnabled}
        onChange={handleToggleChange}
        helperText="Receive notifications for important updates"
      >
        Enable notifications
      </ToggleSwitch>
    </div>
  );
}'
) }}
{% endset %}

{% set accessibilityContent %}
## Accessibility

### ARIA Attributes

The Toggle Switch component uses the following ARIA attributes:

- `role="switch"` - Identifies the element as a switch
- `aria-checked` - Indicates the current state of the switch (true/false)
- `aria-disabled` - Indicates if the switch is currently disabled
- `aria-labelledby` - References the ID of the visible label
- `aria-describedby` - References the ID of any helper or error text

### Keyboard Navigation

| Key | Function |
| --- | -------- |
| `Tab` | Moves focus to the toggle switch |
| `Space` | Toggles the switch between on and off states |
| `Enter` | Toggles the switch between on and off states |

### Screen Reader Support

The toggle switch is implemented using a visually hidden native checkbox to ensure proper screen reader support. The visible toggle is synchronized with the checkbox state.

Screen readers will announce:
- The label text
- The current state (checked/unchecked)
- Any helper text or error messages
- When the state changes

### WCAG Compliance

This component satisfies the following WCAG success criteria:

#### 1.3.1 Info and Relationships (Level A)
The relationship between the toggle and its label is programmatically determined.

#### 1.4.3 Contrast (Minimum) (Level AA)
The toggle has a contrast ratio of at least 3:1 against adjacent colors.

#### 2.1.1 Keyboard (Level A)
The toggle can be operated using only a keyboard.

#### 2.4.7 Focus Visible (Level AA)
The toggle has a visible focus indicator when focused.

#### 4.1.2 Name, Role, Value (Level A)
The toggle's name, role, and state can be programmatically determined.

### Implementation Best Practices

1. Always provide a clear, descriptive label for the toggle
2. Use helper text to provide additional context when necessary
3. Ensure the toggle has sufficient color contrast in all states
4. Test with screen readers to verify proper announcement
5. Ensure the toggle can be operated using only a keyboard
{% endset %}

{{ componentTabs("Toggle Switch", {
  examples: examplesContent,
  design: designContent,
  code: codeContent,
  accessibility: accessibilityContent
}) }}
