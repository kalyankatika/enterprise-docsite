# 11ty Documentation Site with Code Block Component

A simple documentation site built with 11ty that showcases a code block component with tabs and copy functionality.

## Features

- Markdown-based documentation
- Syntax highlighting with Prism.js
- Code blocks with tabs for different languages
- Copy code functionality
- Responsive design

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone this repository
2. Install dependencies:

```bash
npm install
```

### Development

Start the development server:

```bash
npm start
```

This will start a local development server at http://localhost:8080.

### Build

Build the site for production:

```bash
npm run build
```

The built site will be in the `_site` directory.

## Project Structure

```
11ty-codeblock/
├── .eleventy.js        # 11ty configuration
├── package.json        # Project dependencies
├── src/                # Source files
│   ├── _data/          # Global data files
│   ├── _includes/      # Reusable components and partials
│   ├── _layouts/       # Layout templates
│   ├── assets/         # Static assets
│   │   ├── css/        # CSS files
│   │   ├── js/         # JavaScript files
│   │   └── img/        # Images
│   ├── components.md   # Components showcase page
│   └── index.md        # Homepage
└── _site/              # Generated site (not in repo)
```

## Code Block Component

The code block component allows you to display code in multiple languages with tabs and a copy button. To use it in your own pages:

```njk
{% raw %}
{% from "code-block.njk" import codeBlock %}

{{ codeBlock(
  'class MyComponent extends HTMLElement {
  // Your Web Component code here
}
customElements.define("my-component", MyComponent);',
  '<div>Your HTML code here</div>'
) }}
{% endraw %}
```

## License

MIT
