# Prototype Canvas

Enterprise-grade interactive prototype management application for sales teams to create and present product demos using Figma design exports.

## Features

- **Prototype Management** - Create, edit, and organize demo projects by client and industry
- **Image-Based Screens** - Upload Figma design exports (PNG/JPG/GIF) for each screen
- **Variant System** - Create screen variants with different design images for personalized demos
- **Interactive Hotspots** - Draw clickable regions on screens that link to other screens for non-linear navigation
- **Live Preview** - Present prototypes with real-time screen/variant toggling via configuration panel
- **Keyboard Navigation** - Navigate between screens with arrow keys
- **Fullscreen Mode** - Present designs in distraction-free fullscreen mode

## Tech Stack

- **Frontend**: React 18, TypeScript, TailwindCSS, Shadcn UI, TanStack Query
- **Backend**: Express.js, PostgreSQL, Drizzle ORM
- **Storage**: Object storage for image uploads

## Prerequisites

- Node.js 20+
- PostgreSQL database
- VS Code (recommended)

---

## Download and Install (VS Code)

### Step 1: Download the Project

**Option A - Clone with Git:**
```bash
git clone <repository-url>
cd prototype-canvas
```

**Option B - Download ZIP:**
1. Click the green "Code" button on GitHub
2. Select "Download ZIP"
3. Extract the ZIP file to your desired location
4. Open the folder in VS Code

### Step 2: Open in VS Code

1. Open VS Code
2. Go to **File > Open Folder**
3. Select the `prototype-canvas` folder
4. VS Code will detect the project and may prompt you to install recommended extensions

### Step 3: Install Dependencies

Open the VS Code terminal (`Ctrl+` ` or **View > Terminal**) and run:

```bash
npm install
```

### Step 4: Set Up Environment Variables

Create a `.env` file in the root directory:

```env
DATABASE_URL=postgresql://username:password@localhost:5432/prototype_canvas
SESSION_SECRET=your-session-secret-here
```

Replace:
- `username` - Your PostgreSQL username
- `password` - Your PostgreSQL password
- `localhost:5432` - Your database host and port
- `prototype_canvas` - Your database name

### Step 5: Set Up the Database

Run the following command to create the database tables:

```bash
npm run db:push
```

### Step 6: Start the Application

```bash
npm run dev
```

The application will be available at **http://localhost:5000**

---

## Recommended VS Code Extensions

Install these extensions for the best development experience:

| Extension | ID | Purpose |
|-----------|-----|---------|
| ESLint | `dbaeumer.vscode-eslint` | JavaScript/TypeScript linting |
| Prettier | `esbenp.prettier-vscode` | Code formatting |
| Tailwind CSS IntelliSense | `bradlc.vscode-tailwindcss` | Tailwind autocomplete |
| TypeScript Importer | `pmneo.tsimporter` | Auto-import TypeScript modules |
| PostgreSQL | `ckolkman.vscode-postgres` | Database management |

### Quick Install (Terminal)

```bash
code --install-extension dbaeumer.vscode-eslint
code --install-extension esbenp.prettier-vscode
code --install-extension bradlc.vscode-tailwindcss
code --install-extension pmneo.tsimporter
code --install-extension ckolkman.vscode-postgres
```

---

## VS Code Settings (Optional)

Create `.vscode/settings.json` in your project for optimal settings:

```json
{
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": "explicit"
  },
  "typescript.preferences.importModuleSpecifier": "relative",
  "tailwindCSS.includeLanguages": {
    "typescript": "javascript",
    "typescriptreact": "javascript"
  },
  "files.exclude": {
    "node_modules": true
  }
}
```

---

## Usage Guide

### Creating a Prototype

1. Click **"New Prototype"** on the home page
2. Enter the prototype name, client name, and industry
3. Click **"Create Prototype"**

### Adding Screens

1. Open a prototype
2. Click **"Add Screen"**
3. Enter a screen name
4. Click **"Upload Design"** to upload your Figma export (PNG/JPG/GIF)

### Creating Variants

1. Expand a screen card
2. Click **"Add Variant"** 
3. Upload a different design image for this variant
4. Toggle variants on/off to switch between them

### Adding Hotspots (Clickable Regions)

1. Upload an image to a screen first
2. Click **"Add Hotspot"** button (appears after image upload)
3. Draw a rectangle on the image where you want the clickable area
4. Select which screen the hotspot should navigate to
5. In preview mode, clicking the hotspot will jump to that screen

### Presenting to Clients

1. Click the **"Preview"** button to enter presentation mode
2. Use **arrow keys** to navigate between screens
3. Click **"Configure"** to open the configuration panel
4. Toggle screens on/off to show/hide during the presentation
5. Toggle variants to switch between design versions in real-time
6. Click **hotspots** on the screen to navigate non-linearly
7. Press **F** or click the fullscreen button for distraction-free mode

---

## Project Structure

```
prototype-canvas/
├── client/                 # Frontend React application
│   └── src/
│       ├── components/     # UI components (Shadcn)
│       │   ├── ui/         # Base UI components
│       │   └── HotspotEditor.tsx  # Hotspot drawing tools
│       ├── pages/          # Page components
│       │   ├── prototypes.tsx      # Prototype list
│       │   ├── prototype-builder.tsx  # Screen/variant editor
│       │   └── prototype-preview.tsx  # Presentation mode
│       ├── hooks/          # Custom React hooks
│       └── lib/            # Utilities and API client
├── server/                 # Backend Express application
│   ├── routes.ts           # API endpoints
│   ├── storage.ts          # Database operations
│   ├── db.ts               # Database connection
│   └── index.ts            # Server entry point
├── shared/                 # Shared types and schemas
│   └── schema.ts           # Drizzle schema + Zod validation
└── package.json            # Project dependencies
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/prototypes` | List all prototypes |
| POST | `/api/prototypes` | Create a prototype |
| GET | `/api/prototypes/:id` | Get a prototype |
| PATCH | `/api/prototypes/:id` | Update a prototype |
| DELETE | `/api/prototypes/:id` | Delete a prototype |
| GET | `/api/prototypes/:id/screens` | Get screens with variants and hotspots |
| POST | `/api/screens` | Create a screen |
| PATCH | `/api/screens/:id` | Update a screen |
| DELETE | `/api/screens/:id` | Delete a screen |
| POST | `/api/variants` | Create a variant |
| PATCH | `/api/variants/:id` | Update a variant |
| DELETE | `/api/variants/:id` | Delete a variant |
| POST | `/api/hotspots` | Create a hotspot |
| PATCH | `/api/hotspots/:id` | Update a hotspot |
| DELETE | `/api/hotspots/:id` | Delete a hotspot |

---

## Development Commands

```bash
npm run dev          # Start development server (http://localhost:5000)
npm run build        # Build for production
npm run db:push      # Push schema to database
```

---

## Troubleshooting

### "Cannot connect to database"
- Ensure PostgreSQL is running
- Check your `DATABASE_URL` in `.env`
- Make sure the database exists

### "Module not found" errors
- Run `npm install` to install dependencies
- Restart the development server

### Images not uploading
- Check that object storage is configured
- Verify file size is under the limit (10MB recommended)

---

## License

MIT
