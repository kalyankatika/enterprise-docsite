# Prototype Canvas - Enterprise Demo Builder

## Overview
Prototype Canvas is an enterprise application for sales teams to create and present interactive product prototypes with modular screens and configurable variants. It replaces complex Figma prototype stacks with a scalable, dynamic solution that allows real-time configuration during client demos.

## Current State
- **MVP Complete**: Core prototype management with screens and variants
- **Database**: PostgreSQL with Drizzle ORM
- **Frontend**: React with TanStack Query, wouter routing, and Shadcn UI components
- **Backend**: Express.js with full REST API

## Key Features
1. **Prototype Management** - Create, edit, and organize demo projects by client and industry
2. **Image-Based Screens** - Upload Figma design exports (PNG/JPG/GIF) for each screen
3. **Variant System** - Create screen variants with different design images for personalized demos
4. **Interactive Hotspots** - Draw clickable regions on screens that link to other screens for non-linear navigation
5. **Live Preview** - Present prototypes with real-time screen/variant toggling via configuration panel
6. **Screen Navigation** - Navigate between enabled screens with keyboard shortcuts (arrow keys) or clickable hotspots
7. **Fullscreen Mode** - Present designs in distraction-free fullscreen mode

## Tech Stack
- **Frontend**: React 18, TypeScript, TailwindCSS, Shadcn UI, TanStack Query, wouter
- **Backend**: Express.js, PostgreSQL, Drizzle ORM
- **Storage**: Replit Object Storage for image uploads
- **Styling**: Green brand color (#368727), pill-shaped buttons, dark mode support

## Project Structure
```
client/
├── src/
│   ├── components/
│   │   ├── ui/           # Shadcn UI components
│   │   ├── app-sidebar.tsx
│   │   ├── HotspotEditor.tsx  # Hotspot drawing and overlay components
│   │   ├── theme-provider.tsx
│   │   └── theme-toggle.tsx
│   ├── pages/
│   │   ├── prototypes.tsx       # Prototype list/grid
│   │   ├── create-prototype.tsx # Create form
│   │   ├── prototype-builder.tsx # Screen/variant management
│   │   └── prototype-preview.tsx # Presentation mode
│   ├── lib/
│   │   └── queryClient.ts   # API client with query defaults
│   └── App.tsx
server/
├── db.ts          # Database connection
├── storage.ts     # Database operations layer
├── routes.ts      # REST API endpoints
├── seed.ts        # Sample data seeding
└── index.ts       # Server entry point
shared/
└── schema.ts      # Drizzle schema + Zod validation
```

## API Endpoints
- `GET/POST /api/prototypes` - List/create prototypes
- `GET/PATCH/DELETE /api/prototypes/:id` - Single prototype operations
- `GET /api/prototypes/:id/screens` - Get screens with variants and hotspots
- `POST/PATCH/DELETE /api/screens/:id` - Screen operations
- `POST/PATCH/DELETE /api/variants/:id` - Variant operations
- `POST/PATCH/DELETE /api/hotspots/:id` - Hotspot operations

## Database Schema
- **prototypes**: id, name, description, clientName, industry, status, createdAt
- **screens**: id, prototypeId, name, description, type, order, isEnabled, content (JSON)
- **variants**: id, screenId, name, description, isDefault, isActive, content (JSON)
- **hotspots**: id, screenId, targetScreenId, x, y, width, height, name (percentages for responsive scaling)

## Development Commands
- `npm run dev` - Start development server (port 5000)
- `npm run db:push` - Push schema changes to database
- `npm run build` - Production build

## Recent Changes
- **January 30, 2026**: Added interactive hotspots and styling updates
  - Implemented hotspot system for non-linear screen navigation
  - Added HotspotEditor component for drawing clickable zones on screen images
  - Added HotspotOverlay component for rendering clickable hotspots in preview
  - Updated brand color to green (#368727)
  - Changed buttons to pill shape (rounded-full)
- **January 30, 2026**: Refactored to image-based approach using Figma exports
  - Added Object Storage integration for secure file uploads
  - Replaced coded React layouts with image upload areas for screens/variants
  - Updated preview mode to display uploaded images
  - Added useUpload hook for presigned URL upload flow
- Initial MVP implementation (January 2026)
- Full CRUD for prototypes, screens, and variants
- Preview mode with dynamic configuration
- Seed data with sample CRM and Healthcare prototypes

## Technical Notes
- Object storage routes use regex pattern `/^\/objects\/(.*)$/` for Express 5 compatibility
- File uploads use two-step presigned URL flow (request URL, then upload directly)
- Screen/variant content stored as JSONB with optional `imageUrl` field
- All PATCH routes use Zod validation with `.partial()` schemas
