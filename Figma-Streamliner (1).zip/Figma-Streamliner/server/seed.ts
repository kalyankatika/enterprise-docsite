import { storage } from "./storage";
import type { InsertPrototype, InsertScreen, InsertVariant, ScreenContent, VariantContent } from "@shared/schema";

export async function seedDatabase() {
  const existingPrototypes = await storage.getPrototypes();
  if (existingPrototypes.length > 0) {
    console.log("Database already seeded, skipping...");
    return;
  }

  console.log("Seeding database with sample data...");

  const prototypesData: InsertPrototype[] = [
    {
      name: "Enterprise CRM Suite",
      description: "Complete customer relationship management platform demo showcasing sales pipeline, contact management, and analytics dashboards.",
      clientName: "Acme Corporation",
      industry: "Technology",
      status: "active",
    },
    {
      name: "Healthcare Portal",
      description: "Patient management system with appointment scheduling, medical records, and telehealth integration.",
      clientName: "MedCare Systems",
      industry: "Healthcare",
      status: "active",
    },
    {
      name: "Financial Dashboard",
      description: "Real-time financial analytics and reporting platform for investment management.",
      clientName: "Capital Ventures",
      industry: "Finance",
      status: "draft",
    },
  ];

  for (const protoData of prototypesData) {
    const prototype = await storage.createPrototype(protoData);
    console.log(`Created prototype: ${prototype.name}`);

    if (prototype.name === "Enterprise CRM Suite") {
      const screensData: { screen: Omit<InsertScreen, "prototypeId">; variants: Omit<InsertVariant, "screenId">[] }[] = [
        {
          screen: {
            name: "Sales Dashboard",
            description: "Overview of sales performance and key metrics",
            type: "feature",
            order: 0,
            isEnabled: true,
            content: {
              title: "Sales Dashboard",
              subtitle: "Real-time insights into your sales performance",
              layout: "dashboard",
              features: ["Pipeline Analytics", "Deal Tracking", "Team Performance", "Revenue Forecasting"],
              metrics: [
                { label: "Total Revenue", value: "$2.4M" },
                { label: "Active Deals", value: "127" },
                { label: "Win Rate", value: "68%" },
                { label: "Avg Deal Size", value: "$18.9K" },
              ],
            } as ScreenContent,
          },
          variants: [
            {
              name: "Blue Theme",
              description: "Default blue color scheme",
              isDefault: true,
              isActive: true,
              content: { colorScheme: "blue", emphasis: "standard" } as VariantContent,
            },
            {
              name: "Green Theme",
              description: "Growth-focused green theme",
              isDefault: false,
              isActive: false,
              content: { colorScheme: "green", emphasis: "bold" } as VariantContent,
            },
          ],
        },
        {
          screen: {
            name: "Contact Management",
            description: "Manage and organize customer contacts",
            type: "feature",
            order: 1,
            isEnabled: true,
            content: {
              title: "Contact Management",
              subtitle: "Your complete customer database",
              layout: "list",
              features: ["Contact Search", "Custom Fields", "Activity Timeline", "Integration Sync"],
              metrics: [
                { label: "Total Contacts", value: "12,453" },
                { label: "Active", value: "8,291" },
              ],
            } as ScreenContent,
          },
          variants: [
            {
              name: "Standard View",
              isDefault: true,
              isActive: true,
              content: { colorScheme: "blue", emphasis: "standard" } as VariantContent,
            },
          ],
        },
        {
          screen: {
            name: "Analytics & Reports",
            description: "Comprehensive reporting and visualization",
            type: "feature",
            order: 2,
            isEnabled: true,
            content: {
              title: "Analytics & Reports",
              subtitle: "Data-driven insights for better decisions",
              layout: "chart",
              features: ["Custom Reports", "Export Options", "Scheduled Reports", "Trend Analysis"],
              metrics: [
                { label: "Reports Generated", value: "342" },
                { label: "Scheduled", value: "28" },
                { label: "Shared", value: "156" },
                { label: "Downloads", value: "1.2K" },
              ],
            } as ScreenContent,
          },
          variants: [
            {
              name: "Executive View",
              isDefault: true,
              isActive: true,
              content: { colorScheme: "purple", emphasis: "bold" } as VariantContent,
            },
            {
              name: "Operations View",
              isDefault: false,
              isActive: false,
              content: { colorScheme: "orange", emphasis: "standard" } as VariantContent,
            },
          ],
        },
        {
          screen: {
            name: "Settings",
            description: "System configuration and preferences",
            type: "settings",
            order: 3,
            isEnabled: false,
            content: {
              title: "Settings",
              subtitle: "Configure your CRM experience",
              layout: "form",
              features: ["User Preferences", "Notifications", "Integrations", "Security"],
            } as ScreenContent,
          },
          variants: [],
        },
      ];

      for (const { screen, variants } of screensData) {
        const createdScreen = await storage.createScreen({
          ...screen,
          prototypeId: prototype.id,
        });
        console.log(`  Created screen: ${createdScreen.name}`);

        for (const variant of variants) {
          const createdVariant = await storage.createVariant({
            ...variant,
            screenId: createdScreen.id,
          });
          console.log(`    Created variant: ${createdVariant.name}`);
        }
      }
    }

    if (prototype.name === "Healthcare Portal") {
      const screensData: { screen: Omit<InsertScreen, "prototypeId">; variants: Omit<InsertVariant, "screenId">[] }[] = [
        {
          screen: {
            name: "Patient Dashboard",
            description: "Overview of patient health metrics and appointments",
            type: "feature",
            order: 0,
            isEnabled: true,
            content: {
              title: "Patient Dashboard",
              subtitle: "Comprehensive view of patient health status",
              layout: "dashboard",
              features: ["Health Metrics", "Appointment Calendar", "Prescription Tracking", "Care Team"],
              metrics: [
                { label: "Active Patients", value: "2,847" },
                { label: "Today's Appts", value: "43" },
                { label: "Pending Results", value: "18" },
                { label: "Alerts", value: "7" },
              ],
            } as ScreenContent,
          },
          variants: [
            {
              name: "Healthcare Blue",
              isDefault: true,
              isActive: true,
              content: { colorScheme: "blue", emphasis: "standard" } as VariantContent,
            },
            {
              name: "Wellness Green",
              isDefault: false,
              isActive: false,
              content: { colorScheme: "green", emphasis: "standard" } as VariantContent,
            },
          ],
        },
        {
          screen: {
            name: "Medical Records",
            description: "View and manage patient medical history",
            type: "feature",
            order: 1,
            isEnabled: true,
            content: {
              title: "Medical Records",
              subtitle: "Complete patient health history",
              layout: "detail",
              features: ["Visit History", "Lab Results", "Imaging", "Medications", "Allergies"],
              metrics: [
                { label: "Records", value: "156" },
                { label: "Last Visit", value: "3 days" },
              ],
            } as ScreenContent,
          },
          variants: [],
        },
      ];

      for (const { screen, variants } of screensData) {
        const createdScreen = await storage.createScreen({
          ...screen,
          prototypeId: prototype.id,
        });

        for (const variant of variants) {
          await storage.createVariant({
            ...variant,
            screenId: createdScreen.id,
          });
        }
      }
    }
  }

  console.log("Database seeding completed!");
}
