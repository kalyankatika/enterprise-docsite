import { 
  type User, type InsertUser, 
  type Prototype, type InsertPrototype,
  type Screen, type InsertScreen,
  type Variant, type InsertVariant,
  type Hotspot, type InsertHotspot,
  users, prototypes, screens, variants, hotspots
} from "@shared/schema";
import { db } from "./db";
import { eq, asc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getPrototypes(): Promise<Prototype[]>;
  getPrototype(id: string): Promise<Prototype | undefined>;
  createPrototype(prototype: InsertPrototype): Promise<Prototype>;
  updatePrototype(id: string, prototype: Partial<InsertPrototype>): Promise<Prototype | undefined>;
  deletePrototype(id: string): Promise<boolean>;

  getScreensByPrototype(prototypeId: string): Promise<(Screen & { variants: Variant[]; hotspots: Hotspot[] })[]>;
  getScreen(id: string): Promise<Screen | undefined>;
  createScreen(screen: InsertScreen): Promise<Screen>;
  updateScreen(id: string, screen: Partial<InsertScreen>): Promise<Screen | undefined>;
  deleteScreen(id: string): Promise<boolean>;

  getVariantsByScreen(screenId: string): Promise<Variant[]>;
  getVariant(id: string): Promise<Variant | undefined>;
  createVariant(variant: InsertVariant): Promise<Variant>;
  updateVariant(id: string, variant: Partial<InsertVariant>): Promise<Variant | undefined>;
  deleteVariant(id: string): Promise<boolean>;

  getHotspotsByScreen(screenId: string): Promise<Hotspot[]>;
  getHotspot(id: string): Promise<Hotspot | undefined>;
  createHotspot(hotspot: InsertHotspot): Promise<Hotspot>;
  updateHotspot(id: string, hotspot: Partial<InsertHotspot>): Promise<Hotspot | undefined>;
  deleteHotspot(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getPrototypes(): Promise<Prototype[]> {
    return db.select().from(prototypes).orderBy(asc(prototypes.createdAt));
  }

  async getPrototype(id: string): Promise<Prototype | undefined> {
    const [prototype] = await db.select().from(prototypes).where(eq(prototypes.id, id));
    return prototype;
  }

  async createPrototype(prototype: InsertPrototype): Promise<Prototype> {
    const [created] = await db.insert(prototypes).values(prototype).returning();
    return created;
  }

  async updatePrototype(id: string, prototype: Partial<InsertPrototype>): Promise<Prototype | undefined> {
    const [updated] = await db.update(prototypes).set(prototype).where(eq(prototypes.id, id)).returning();
    return updated;
  }

  async deletePrototype(id: string): Promise<boolean> {
    const result = await db.delete(prototypes).where(eq(prototypes.id, id));
    return true;
  }

  async getScreensByPrototype(prototypeId: string): Promise<(Screen & { variants: Variant[]; hotspots: Hotspot[] })[]> {
    const screenList = await db
      .select()
      .from(screens)
      .where(eq(screens.prototypeId, prototypeId))
      .orderBy(asc(screens.order));
    
    const screensWithVariantsAndHotspots = await Promise.all(
      screenList.map(async (screen) => {
        const screenVariants = await this.getVariantsByScreen(screen.id);
        const screenHotspots = await this.getHotspotsByScreen(screen.id);
        return { ...screen, variants: screenVariants, hotspots: screenHotspots };
      })
    );
    
    return screensWithVariantsAndHotspots;
  }

  async getScreen(id: string): Promise<Screen | undefined> {
    const [screen] = await db.select().from(screens).where(eq(screens.id, id));
    return screen;
  }

  async createScreen(screen: InsertScreen): Promise<Screen> {
    const [created] = await db.insert(screens).values(screen).returning();
    return created;
  }

  async updateScreen(id: string, screen: Partial<InsertScreen>): Promise<Screen | undefined> {
    const [updated] = await db.update(screens).set(screen).where(eq(screens.id, id)).returning();
    return updated;
  }

  async deleteScreen(id: string): Promise<boolean> {
    await db.delete(screens).where(eq(screens.id, id));
    return true;
  }

  async getVariantsByScreen(screenId: string): Promise<Variant[]> {
    return db.select().from(variants).where(eq(variants.screenId, screenId));
  }

  async getVariant(id: string): Promise<Variant | undefined> {
    const [variant] = await db.select().from(variants).where(eq(variants.id, id));
    return variant;
  }

  async createVariant(variant: InsertVariant): Promise<Variant> {
    const [created] = await db.insert(variants).values(variant).returning();
    return created;
  }

  async updateVariant(id: string, variant: Partial<InsertVariant>): Promise<Variant | undefined> {
    const [updated] = await db.update(variants).set(variant).where(eq(variants.id, id)).returning();
    return updated;
  }

  async deleteVariant(id: string): Promise<boolean> {
    await db.delete(variants).where(eq(variants.id, id));
    return true;
  }

  async getHotspotsByScreen(screenId: string): Promise<Hotspot[]> {
    return db.select().from(hotspots).where(eq(hotspots.screenId, screenId));
  }

  async getHotspot(id: string): Promise<Hotspot | undefined> {
    const [hotspot] = await db.select().from(hotspots).where(eq(hotspots.id, id));
    return hotspot;
  }

  async createHotspot(hotspot: InsertHotspot): Promise<Hotspot> {
    const [created] = await db.insert(hotspots).values(hotspot).returning();
    return created;
  }

  async updateHotspot(id: string, hotspot: Partial<InsertHotspot>): Promise<Hotspot | undefined> {
    const [updated] = await db.update(hotspots).set(hotspot).where(eq(hotspots.id, id)).returning();
    return updated;
  }

  async deleteHotspot(id: string): Promise<boolean> {
    await db.delete(hotspots).where(eq(hotspots.id, id));
    return true;
  }
}

export const storage = new DatabaseStorage();
