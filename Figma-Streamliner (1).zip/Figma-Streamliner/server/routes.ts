import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPrototypeSchema, insertScreenSchema, insertVariantSchema, insertHotspotSchema } from "@shared/schema";
import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";

const updatePrototypeSchema = insertPrototypeSchema.partial();
const updateScreenSchema = insertScreenSchema.partial();
const updateVariantSchema = insertVariantSchema.partial();
const updateHotspotSchema = insertHotspotSchema.partial();

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Register object storage routes for image uploads
  registerObjectStorageRoutes(app);
  
  // Prototypes CRUD
  app.get("/api/prototypes", async (req, res) => {
    try {
      const prototypes = await storage.getPrototypes();
      res.json(prototypes);
    } catch (error) {
      console.error("Error fetching prototypes:", error);
      res.status(500).json({ error: "Failed to fetch prototypes" });
    }
  });

  app.get("/api/prototypes/:id", async (req, res) => {
    try {
      const prototype = await storage.getPrototype(req.params.id);
      if (!prototype) {
        return res.status(404).json({ error: "Prototype not found" });
      }
      res.json(prototype);
    } catch (error) {
      console.error("Error fetching prototype:", error);
      res.status(500).json({ error: "Failed to fetch prototype" });
    }
  });

  app.post("/api/prototypes", async (req, res) => {
    try {
      const parsed = insertPrototypeSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid prototype data", details: parsed.error });
      }
      const prototype = await storage.createPrototype(parsed.data);
      res.status(201).json(prototype);
    } catch (error) {
      console.error("Error creating prototype:", error);
      res.status(500).json({ error: "Failed to create prototype" });
    }
  });

  app.patch("/api/prototypes/:id", async (req, res) => {
    try {
      const parsed = updatePrototypeSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid prototype data", details: parsed.error });
      }
      const prototype = await storage.updatePrototype(req.params.id, parsed.data);
      if (!prototype) {
        return res.status(404).json({ error: "Prototype not found" });
      }
      res.json(prototype);
    } catch (error) {
      console.error("Error updating prototype:", error);
      res.status(500).json({ error: "Failed to update prototype" });
    }
  });

  app.delete("/api/prototypes/:id", async (req, res) => {
    try {
      await storage.deletePrototype(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting prototype:", error);
      res.status(500).json({ error: "Failed to delete prototype" });
    }
  });

  // Screens CRUD
  app.get("/api/prototypes/:prototypeId/screens", async (req, res) => {
    try {
      const screens = await storage.getScreensByPrototype(req.params.prototypeId);
      res.json(screens);
    } catch (error) {
      console.error("Error fetching screens:", error);
      res.status(500).json({ error: "Failed to fetch screens" });
    }
  });

  app.post("/api/screens", async (req, res) => {
    try {
      const parsed = insertScreenSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid screen data", details: parsed.error });
      }
      const screen = await storage.createScreen(parsed.data);
      res.status(201).json(screen);
    } catch (error) {
      console.error("Error creating screen:", error);
      res.status(500).json({ error: "Failed to create screen" });
    }
  });

  app.patch("/api/screens/:id", async (req, res) => {
    try {
      const parsed = updateScreenSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid screen data", details: parsed.error });
      }
      const screen = await storage.updateScreen(req.params.id, parsed.data);
      if (!screen) {
        return res.status(404).json({ error: "Screen not found" });
      }
      res.json(screen);
    } catch (error) {
      console.error("Error updating screen:", error);
      res.status(500).json({ error: "Failed to update screen" });
    }
  });

  app.delete("/api/screens/:id", async (req, res) => {
    try {
      await storage.deleteScreen(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting screen:", error);
      res.status(500).json({ error: "Failed to delete screen" });
    }
  });

  // Variants CRUD
  app.post("/api/variants", async (req, res) => {
    try {
      const parsed = insertVariantSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid variant data", details: parsed.error });
      }
      const variant = await storage.createVariant(parsed.data);
      res.status(201).json(variant);
    } catch (error) {
      console.error("Error creating variant:", error);
      res.status(500).json({ error: "Failed to create variant" });
    }
  });

  app.patch("/api/variants/:id", async (req, res) => {
    try {
      const parsed = updateVariantSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid variant data", details: parsed.error });
      }
      const variant = await storage.updateVariant(req.params.id, parsed.data);
      if (!variant) {
        return res.status(404).json({ error: "Variant not found" });
      }
      res.json(variant);
    } catch (error) {
      console.error("Error updating variant:", error);
      res.status(500).json({ error: "Failed to update variant" });
    }
  });

  app.delete("/api/variants/:id", async (req, res) => {
    try {
      await storage.deleteVariant(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting variant:", error);
      res.status(500).json({ error: "Failed to delete variant" });
    }
  });

  // Hotspots CRUD
  app.post("/api/hotspots", async (req, res) => {
    try {
      const parsed = insertHotspotSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid hotspot data", details: parsed.error });
      }
      const hotspot = await storage.createHotspot(parsed.data);
      res.status(201).json(hotspot);
    } catch (error) {
      console.error("Error creating hotspot:", error);
      res.status(500).json({ error: "Failed to create hotspot" });
    }
  });

  app.patch("/api/hotspots/:id", async (req, res) => {
    try {
      const parsed = updateHotspotSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid hotspot data", details: parsed.error });
      }
      const hotspot = await storage.updateHotspot(req.params.id, parsed.data);
      if (!hotspot) {
        return res.status(404).json({ error: "Hotspot not found" });
      }
      res.json(hotspot);
    } catch (error) {
      console.error("Error updating hotspot:", error);
      res.status(500).json({ error: "Failed to update hotspot" });
    }
  });

  app.delete("/api/hotspots/:id", async (req, res) => {
    try {
      await storage.deleteHotspot(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting hotspot:", error);
      res.status(500).json({ error: "Failed to delete hotspot" });
    }
  });

  return httpServer;
}
