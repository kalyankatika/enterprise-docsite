import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useParams } from "wouter";
import { 
  ArrowLeft, 
  ChevronLeft, 
  ChevronRight,
  Settings2,
  Maximize2,
  Minimize2,
  Eye,
  EyeOff,
  Image as ImageIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { HotspotOverlay } from "@/components/HotspotEditor";
import type { Prototype, Screen, Variant, Hotspot } from "@shared/schema";

interface ScreenWithVariants extends Screen {
  variants?: Variant[];
  hotspots?: Hotspot[];
}

function ScreenDisplay({ 
  screen, 
  activeVariant, 
  onHotspotClick,
  allScreens,
}: { 
  screen: ScreenWithVariants; 
  activeVariant?: Variant;
  onHotspotClick?: (targetScreenId: string) => void;
  allScreens?: ScreenWithVariants[];
}) {
  const imageUrl = activeVariant?.content?.imageUrl || screen.content?.imageUrl;

  if (!imageUrl) {
    return (
      <div className="flex-1 flex items-center justify-center bg-muted/30 rounded-md border-2 border-dashed">
        <div className="text-center p-6">
          <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <h3 className="text-base font-medium mb-1">{screen.name}</h3>
          <p className="text-sm text-muted-foreground">
            No design uploaded yet.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex items-center justify-center p-2 overflow-auto">
      <div className="relative max-w-full max-h-full">
        <img 
          src={imageUrl}
          alt={screen.name}
          className="max-w-full max-h-full object-contain rounded-md shadow-lg"
          data-testid={`image-screen-${screen.id}`}
        />
        {screen.hotspots && screen.hotspots.length > 0 && onHotspotClick && (
          <HotspotOverlay
            hotspots={screen.hotspots}
            onHotspotClick={onHotspotClick}
            allScreens={allScreens}
          />
        )}
      </div>
    </div>
  );
}

function ConfigurationPanel({ 
  screens, 
  prototypeId,
  currentScreenIndex,
  onScreenChange,
}: { 
  screens: ScreenWithVariants[];
  prototypeId: string;
  currentScreenIndex: number;
  onScreenChange: (index: number) => void;
}) {
  const toggleScreenMutation = useMutation({
    mutationFn: async ({ screenId, isEnabled }: { screenId: string; isEnabled: boolean }) => {
      await apiRequest("PATCH", `/api/screens/${screenId}`, { isEnabled });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
    },
  });

  const toggleVariantMutation = useMutation({
    mutationFn: async ({ variantId, isActive }: { variantId: string; isActive: boolean }) => {
      await apiRequest("PATCH", `/api/variants/${variantId}`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
    },
  });

  return (
    <ScrollArea className="h-full">
      <div className="space-y-4 p-1">
        <div>
          <h4 className="text-sm font-medium mb-3">Screens</h4>
          <div className="space-y-2">
            {screens.map((screen, index) => (
              <div 
                key={screen.id} 
                className={`p-3 rounded-md border transition-colors ${
                  index === currentScreenIndex ? "bg-accent border-accent" : "hover-elevate"
                }`}
              >
                <div className="flex items-center gap-3">
                  <Switch
                    checked={screen.isEnabled}
                    onCheckedChange={(checked) => 
                      toggleScreenMutation.mutate({ screenId: screen.id, isEnabled: checked })
                    }
                    data-testid={`switch-screen-${screen.id}`}
                  />
                  <button 
                    className="flex-1 text-left"
                    onClick={() => onScreenChange(index)}
                    data-testid={`button-goto-screen-${screen.id}`}
                  >
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium">{screen.name}</p>
                      {!screen.isEnabled && (
                        <Badge variant="outline" className="text-xs">Hidden</Badge>
                      )}
                    </div>
                    {screen.content?.imageUrl && (
                      <img 
                        src={screen.content.imageUrl}
                        alt={screen.name}
                        className="mt-2 h-16 w-full object-cover rounded border"
                      />
                    )}
                  </button>
                </div>

                {screen.variants && screen.variants.length > 0 && (
                  <div className="mt-3 pl-8 space-y-2">
                    <p className="text-xs text-muted-foreground font-medium">Variants</p>
                    {screen.variants.map((variant) => (
                      <div 
                        key={variant.id} 
                        className="flex items-center gap-2 p-2 rounded bg-muted/50"
                      >
                        <Switch
                          checked={variant.isActive}
                          onCheckedChange={(checked) =>
                            toggleVariantMutation.mutate({ variantId: variant.id, isActive: checked })
                          }
                          data-testid={`switch-variant-${variant.id}`}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm truncate">{variant.name}</p>
                          {variant.content?.imageUrl && (
                            <img 
                              src={variant.content.imageUrl}
                              alt={variant.name}
                              className="mt-1 h-10 w-full object-cover rounded border"
                            />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </ScrollArea>
  );
}

export default function PrototypePreviewPage() {
  const params = useParams<{ id: string }>();
  const prototypeId = params.id;
  const [currentScreenIndex, setCurrentScreenIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const { data: prototype, isLoading: prototypeLoading } = useQuery<Prototype>({
    queryKey: ["/api/prototypes", prototypeId],
    enabled: !!prototypeId,
  });

  const { data: allScreens, isLoading: screensLoading } = useQuery<ScreenWithVariants[]>({
    queryKey: ["/api/prototypes", prototypeId, "screens"],
    enabled: !!prototypeId,
  });

  const enabledScreens = allScreens?.filter(s => s.isEnabled) || [];
  const currentScreen = enabledScreens[currentScreenIndex];
  
  const activeVariant = currentScreen?.variants?.find(v => v.isActive);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" && currentScreenIndex < enabledScreens.length - 1) {
        setCurrentScreenIndex(i => i + 1);
      } else if (e.key === "ArrowLeft" && currentScreenIndex > 0) {
        setCurrentScreenIndex(i => i - 1);
      } else if (e.key === "Escape" && isFullscreen) {
        setIsFullscreen(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentScreenIndex, enabledScreens.length, isFullscreen]);

  useEffect(() => {
    if (currentScreenIndex >= enabledScreens.length && enabledScreens.length > 0) {
      setCurrentScreenIndex(enabledScreens.length - 1);
    }
  }, [enabledScreens.length, currentScreenIndex]);

  const handleScreenChange = (index: number) => {
    const allScreenIndex = allScreens?.findIndex(s => s.id === enabledScreens[index]?.id);
    if (allScreenIndex !== undefined && allScreenIndex >= 0) {
      const enabledIndex = enabledScreens.findIndex(s => s.id === allScreens?.[allScreenIndex]?.id);
      if (enabledIndex >= 0) {
        setCurrentScreenIndex(enabledIndex);
      }
    }
  };

  const handleHotspotClick = (targetScreenId: string) => {
    const targetIndex = enabledScreens.findIndex(s => s.id === targetScreenId);
    if (targetIndex >= 0) {
      setCurrentScreenIndex(targetIndex);
    }
  };

  const handleConfigScreenChange = (allScreensIndex: number) => {
    const screen = allScreens?.[allScreensIndex];
    if (screen && screen.isEnabled) {
      const enabledIndex = enabledScreens.findIndex(s => s.id === screen.id);
      if (enabledIndex >= 0) {
        setCurrentScreenIndex(enabledIndex);
      }
    }
  };

  if (prototypeLoading || screensLoading) {
    return (
      <div className="flex-1 flex flex-col">
        <div className="border-b p-4">
          <div className="flex items-center gap-4">
            <Skeleton className="h-9 w-9" />
            <Skeleton className="h-6 w-48" />
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <Skeleton className="h-96 w-full max-w-4xl" />
        </div>
      </div>
    );
  }

  if (!prototype) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Prototype not found</h2>
          <p className="text-muted-foreground mb-4">The prototype you're looking for doesn't exist.</p>
          <Link href="/">
            <Button>Back to Prototypes</Button>
          </Link>
        </div>
      </div>
    );
  }

  if (enabledScreens.length === 0) {
    return (
      <div className="flex-1 flex flex-col">
        <div className="border-b bg-card">
          <div className="container py-4">
            <div className="flex items-center gap-4">
              <Link href={`/prototype/${prototypeId}`}>
                <Button variant="ghost" size="icon" data-testid="button-back">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-semibold">{prototype.name}</h1>
                <p className="text-sm text-muted-foreground">Preview Mode</p>
              </div>
            </div>
          </div>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <EyeOff className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">No screens to display</h2>
            <p className="text-muted-foreground mb-4">
              All screens are disabled or no screens have been added yet.
            </p>
            <Link href={`/prototype/${prototypeId}`}>
              <Button>Go to Builder</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (isFullscreen) {
    return (
      <div className="fixed inset-0 z-50 bg-background flex flex-col">
        <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
          <Badge variant="secondary">
            {currentScreenIndex + 1} / {enabledScreens.length}
          </Badge>
          <Button 
            variant="secondary" 
            size="icon"
            onClick={() => setIsFullscreen(false)}
            data-testid="button-exit-fullscreen"
          >
            <Minimize2 className="h-4 w-4" />
          </Button>
        </div>

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 flex items-center gap-2">
          <Button
            variant="secondary"
            size="icon"
            onClick={() => setCurrentScreenIndex(i => Math.max(0, i - 1))}
            disabled={currentScreenIndex === 0}
            data-testid="button-prev-fullscreen"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="secondary"
            size="icon"
            onClick={() => setCurrentScreenIndex(i => Math.min(enabledScreens.length - 1, i + 1))}
            disabled={currentScreenIndex === enabledScreens.length - 1}
            data-testid="button-next-fullscreen"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {currentScreen && (
          <ScreenDisplay 
            screen={currentScreen} 
            activeVariant={activeVariant}
            onHotspotClick={handleHotspotClick}
            allScreens={enabledScreens}
          />
        )}
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="border-b bg-card">
        <div className="container py-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-4">
              <Link href={`/prototype/${prototypeId}`}>
                <Button variant="ghost" size="icon" data-testid="button-back">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <div>
                <h1 className="text-lg font-semibold">{prototype.name}</h1>
                <p className="text-sm text-muted-foreground">
                  {currentScreen?.name || "Preview"}
                  {activeVariant && ` • ${activeVariant.name}`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-muted rounded-md p-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setCurrentScreenIndex(i => Math.max(0, i - 1))}
                  disabled={currentScreenIndex === 0}
                  data-testid="button-prev"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm px-2 min-w-[4rem] text-center">
                  {currentScreenIndex + 1} / {enabledScreens.length}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setCurrentScreenIndex(i => Math.min(enabledScreens.length - 1, i + 1))}
                  disabled={currentScreenIndex === enabledScreens.length - 1}
                  data-testid="button-next"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>

              <Button
                variant="outline"
                size="icon"
                onClick={() => setIsFullscreen(true)}
                data-testid="button-fullscreen"
              >
                <Maximize2 className="h-4 w-4" />
              </Button>

              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" className="gap-2" data-testid="button-config">
                    <Settings2 className="h-4 w-4" />
                    Configure
                  </Button>
                </SheetTrigger>
                <SheetContent className="w-80 sm:w-96">
                  <SheetHeader>
                    <SheetTitle>Configuration</SheetTitle>
                    <SheetDescription>
                      Toggle screens and variants for your presentation
                    </SheetDescription>
                  </SheetHeader>
                  <div className="mt-4 h-[calc(100vh-8rem)]">
                    {allScreens && (
                      <ConfigurationPanel
                        screens={allScreens}
                        prototypeId={prototypeId}
                        currentScreenIndex={allScreens.findIndex(s => s.id === currentScreen?.id)}
                        onScreenChange={handleConfigScreenChange}
                      />
                    )}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden bg-muted/20">
        {currentScreen && (
          <ScreenDisplay 
            screen={currentScreen} 
            activeVariant={activeVariant}
            onHotspotClick={handleHotspotClick}
            allScreens={enabledScreens}
          />
        )}
      </div>
    </div>
  );
}
