import { useState, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useParams } from "wouter";
import { 
  ArrowLeft, 
  Plus, 
  Play, 
  Layers,
  Eye,
  EyeOff,
  GripVertical,
  MoreHorizontal,
  Trash2,
  Copy,
  Upload,
  Image as ImageIcon,
  ChevronRight,
  ChevronDown,
  MousePointer2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useUpload } from "@/hooks/use-upload";
import type { Prototype, Screen, Variant, ScreenContent, Hotspot } from "@shared/schema";
import { HotspotEditor } from "@/components/HotspotEditor";

interface ScreenWithVariants extends Screen {
  variants?: Variant[];
  hotspots?: Hotspot[];
}

function ImageUploadArea({ 
  imageUrl, 
  onUpload, 
  isUploading,
  label = "Upload Design"
}: { 
  imageUrl?: string; 
  onUpload: (file: File) => void;
  isUploading: boolean;
  label?: string;
}) {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUpload(file);
    }
  };

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium">{label}</label>
      {imageUrl ? (
        <div className="relative group">
          <img 
            src={imageUrl} 
            alt="Screen design" 
            className="w-full h-40 object-cover rounded-md border"
          />
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-md">
            <label className="cursor-pointer">
              <input 
                type="file" 
                accept="image/*" 
                onChange={handleFileChange}
                className="hidden"
                disabled={isUploading}
              />
              <Button variant="secondary" size="sm" className="pointer-events-none">
                <Upload className="h-4 w-4 mr-2" />
                Replace Image
              </Button>
            </label>
          </div>
        </div>
      ) : (
        <label className="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed rounded-md cursor-pointer hover:bg-muted/50 transition-colors">
          <input 
            type="file" 
            accept="image/*" 
            onChange={handleFileChange}
            className="hidden"
            disabled={isUploading}
          />
          <div className="flex flex-col items-center">
            {isUploading ? (
              <div className="animate-pulse text-muted-foreground">Uploading...</div>
            ) : (
              <>
                <ImageIcon className="h-8 w-8 text-muted-foreground mb-2" />
                <span className="text-sm text-muted-foreground">Click to upload Figma export</span>
                <span className="text-xs text-muted-foreground mt-1">PNG, JPG up to 10MB</span>
              </>
            )}
          </div>
        </label>
      )}
    </div>
  );
}

function AddScreenDialog({ prototypeId, onSuccess }: { prototypeId: string; onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [uploadedImagePath, setUploadedImagePath] = useState<string | null>(null);
  const { toast } = useToast();
  const { uploadFile, isUploading } = useUpload({
    onSuccess: (response) => {
      setUploadedImagePath(response.objectPath);
      toast({ title: "Image uploaded", description: "Your design has been uploaded." });
    },
    onError: (error) => {
      toast({ title: "Upload failed", description: error.message, variant: "destructive" });
    },
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const content: ScreenContent = {
        title: name,
        imageUrl: uploadedImagePath || undefined,
      };
      await apiRequest("POST", "/api/screens", {
        prototypeId,
        name,
        type: "feature",
        isEnabled: true,
        content,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
      toast({ title: "Screen added", description: "New screen has been created." });
      setOpen(false);
      setName("");
      setUploadedImagePath(null);
      onSuccess();
    },
  });

  const handleImageUpload = useCallback(async (file: File) => {
    await uploadFile(file);
  }, [uploadFile]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2" data-testid="button-add-screen">
          <Plus className="h-4 w-4" />
          Add Screen
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Add New Screen</DialogTitle>
          <DialogDescription>
            Upload a Figma design export to create a new screen.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Screen Name</label>
            <Input
              placeholder="e.g., Dashboard Overview"
              value={name}
              onChange={(e) => setName(e.target.value)}
              data-testid="input-screen-name"
            />
          </div>
          <ImageUploadArea
            imageUrl={uploadedImagePath ? uploadedImagePath : undefined}
            onUpload={handleImageUpload}
            isUploading={isUploading}
            label="Design Image"
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button 
            onClick={() => createMutation.mutate()} 
            disabled={!name || createMutation.isPending}
            data-testid="button-create-screen"
          >
            {createMutation.isPending ? "Creating..." : "Create Screen"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function VariantItem({ 
  variant, 
  screenId,
  prototypeId,
  onToggle,
  onDelete 
}: { 
  variant: Variant;
  screenId: string;
  prototypeId: string;
  onToggle: () => void;
  onDelete: () => void;
}) {
  const { toast } = useToast();
  const { uploadFile, isUploading } = useUpload({
    onSuccess: async (response) => {
      await apiRequest("PATCH", `/api/variants/${variant.id}`, {
        content: { ...variant.content, imageUrl: response.objectPath },
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
      toast({ title: "Variant image updated" });
    },
    onError: (error) => {
      toast({ title: "Upload failed", description: error.message, variant: "destructive" });
    },
  });

  const handleImageUpload = async (file: File) => {
    await uploadFile(file);
  };

  const imageUrl = variant.content?.imageUrl;

  return (
    <div className="flex items-center gap-3 py-2 px-3 rounded-md bg-muted/50">
      <Switch 
        checked={variant.isActive} 
        onCheckedChange={onToggle}
        data-testid={`switch-variant-${variant.id}`}
      />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="text-sm font-medium truncate">{variant.name}</p>
          {variant.isDefault && (
            <Badge variant="outline" className="text-xs">Default</Badge>
          )}
        </div>
        {variant.description && (
          <p className="text-xs text-muted-foreground truncate">{variant.description}</p>
        )}
      </div>
      <div className="flex items-center gap-2">
        {imageUrl ? (
          <div className="relative group">
            <img 
              src={imageUrl} 
              alt={variant.name} 
              className="h-10 w-16 object-cover rounded border"
            />
            <label className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer rounded">
              <input 
                type="file" 
                accept="image/*" 
                onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0])}
                className="hidden"
                disabled={isUploading}
              />
              <Upload className="h-3 w-3 text-white" />
            </label>
          </div>
        ) : (
          <label className="flex items-center justify-center h-10 w-16 border-2 border-dashed rounded cursor-pointer hover:bg-muted/50">
            <input 
              type="file" 
              accept="image/*" 
              onChange={(e) => e.target.files?.[0] && handleImageUpload(e.target.files[0])}
              className="hidden"
              disabled={isUploading}
            />
            {isUploading ? (
              <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            ) : (
              <ImageIcon className="h-4 w-4 text-muted-foreground" />
            )}
          </label>
        )}
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-7 w-7"
          onClick={onDelete}
          data-testid={`button-delete-variant-${variant.id}`}
        >
          <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
        </Button>
      </div>
    </div>
  );
}

function ScreenCard({ 
  screen, 
  prototypeId,
  allScreens,
}: { 
  screen: ScreenWithVariants; 
  prototypeId: string;
  allScreens: ScreenWithVariants[];
}) {
  const [expanded, setExpanded] = useState(false);
  const [addingVariant, setAddingVariant] = useState(false);
  const [variantName, setVariantName] = useState("");
  const { toast } = useToast();
  const { uploadFile, isUploading: isUploadingScreen } = useUpload({
    onSuccess: async (response) => {
      await apiRequest("PATCH", `/api/screens/${screen.id}`, {
        content: { ...screen.content, imageUrl: response.objectPath },
      });
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
      toast({ title: "Screen image updated" });
    },
    onError: (error) => {
      toast({ title: "Upload failed", description: error.message, variant: "destructive" });
    },
  });

  const toggleMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("PATCH", `/api/screens/${screen.id}`, {
        isEnabled: !screen.isEnabled,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/screens/${screen.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
      toast({ title: "Screen deleted" });
    },
  });

  const addVariantMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/variants", {
        screenId: screen.id,
        name: variantName,
        isDefault: false,
        isActive: false,
        content: {},
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
      setAddingVariant(false);
      setVariantName("");
      toast({ title: "Variant added" });
    },
  });

  const toggleVariantMutation = useMutation({
    mutationFn: async (variantId: string) => {
      const variant = screen.variants?.find(v => v.id === variantId);
      await apiRequest("PATCH", `/api/variants/${variantId}`, {
        isActive: !variant?.isActive,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
    },
  });

  const deleteVariantMutation = useMutation({
    mutationFn: async (variantId: string) => {
      await apiRequest("DELETE", `/api/variants/${variantId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
      toast({ title: "Variant deleted" });
    },
  });

  const handleScreenImageUpload = async (file: File) => {
    await uploadFile(file);
  };

  const screenImageUrl = screen.content?.imageUrl;

  return (
    <Card className={`transition-all ${!screen.isEnabled ? "opacity-60" : ""}`} data-testid={`card-screen-${screen.id}`}>
      <Collapsible open={expanded} onOpenChange={setExpanded}>
        <CardHeader className="pb-3">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 cursor-grab text-muted-foreground">
              <GripVertical className="h-4 w-4" />
            </div>
            
            {screenImageUrl ? (
              <div className="relative group">
                <img 
                  src={screenImageUrl} 
                  alt={screen.name} 
                  className="h-12 w-20 object-cover rounded-md border"
                />
                <label className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer rounded-md">
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={(e) => e.target.files?.[0] && handleScreenImageUpload(e.target.files[0])}
                    className="hidden"
                    disabled={isUploadingScreen}
                  />
                  <Upload className="h-4 w-4 text-white" />
                </label>
              </div>
            ) : (
              <label className="flex items-center justify-center h-12 w-20 border-2 border-dashed rounded-md cursor-pointer hover:bg-muted/50 transition-colors">
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={(e) => e.target.files?.[0] && handleScreenImageUpload(e.target.files[0])}
                  className="hidden"
                  disabled={isUploadingScreen}
                />
                {isUploadingScreen ? (
                  <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                ) : (
                  <ImageIcon className="h-5 w-5 text-muted-foreground" />
                )}
              </label>
            )}
            
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <CardTitle className="text-base">{screen.name}</CardTitle>
                {screen.variants && screen.variants.length > 0 && (
                  <Badge variant="secondary" className="text-xs">
                    {screen.variants.length} variant{screen.variants.length !== 1 ? 's' : ''}
                  </Badge>
                )}
              </div>
              {screen.description && (
                <CardDescription className="mt-0.5">{screen.description}</CardDescription>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => toggleMutation.mutate()}
                data-testid={`button-toggle-screen-${screen.id}`}
              >
                {screen.isEnabled ? (
                  <Eye className="h-4 w-4" />
                ) : (
                  <EyeOff className="h-4 w-4" />
                )}
              </Button>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" size="icon" data-testid={`button-expand-screen-${screen.id}`}>
                  {expanded ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </Button>
              </CollapsibleTrigger>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" data-testid={`button-menu-screen-${screen.id}`}>
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>
                    <Copy className="h-4 w-4 mr-2" />
                    Duplicate
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="text-destructive focus:text-destructive"
                    onClick={() => deleteMutation.mutate()}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </CardHeader>
        <CollapsibleContent>
          <CardContent className="pt-0">
            <Separator className="mb-4" />
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium">Variants</h4>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="gap-1 h-7"
                  onClick={() => setAddingVariant(true)}
                  data-testid={`button-add-variant-${screen.id}`}
                >
                  <Plus className="h-3 w-3" />
                  Add Variant
                </Button>
              </div>
              
              {addingVariant && (
                <div className="flex items-center gap-2 p-3 rounded-md border bg-muted/30">
                  <Input
                    placeholder="Variant name (e.g., Enterprise Version)"
                    value={variantName}
                    onChange={(e) => setVariantName(e.target.value)}
                    className="flex-1"
                    data-testid="input-variant-name"
                  />
                  <Button 
                    size="sm"
                    onClick={() => addVariantMutation.mutate()}
                    disabled={!variantName || addVariantMutation.isPending}
                    data-testid="button-save-variant"
                  >
                    Add
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setAddingVariant(false)}
                  >
                    Cancel
                  </Button>
                </div>
              )}

              {screen.variants && screen.variants.length > 0 ? (
                <div className="space-y-2">
                  {screen.variants.map((variant) => (
                    <VariantItem
                      key={variant.id}
                      variant={variant}
                      screenId={screen.id}
                      prototypeId={prototypeId}
                      onToggle={() => toggleVariantMutation.mutate(variant.id)}
                      onDelete={() => deleteVariantMutation.mutate(variant.id)}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-2">
                  No variants yet. Add variants to create alternative versions.
                </p>
              )}

              <Separator className="my-3" />
              {screenImageUrl ? (
                <HotspotEditor
                  screenId={screen.id}
                  prototypeId={prototypeId}
                  imageUrl={screenImageUrl}
                  hotspots={screen.hotspots || []}
                  allScreens={allScreens}
                />
              ) : (
                <div className="text-sm text-muted-foreground text-center py-2">
                  <MousePointer2 className="h-4 w-4 inline-block mr-1" />
                  Upload an image to add clickable hotspots for non-linear navigation
                </div>
              )}
            </div>
          </CardContent>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
}

function ScreensSkeleton() {
  return (
    <div className="space-y-4">
      {[1, 2, 3].map((i) => (
        <Card key={i}>
          <CardHeader>
            <div className="flex items-center gap-3">
              <Skeleton className="h-4 w-4" />
              <Skeleton className="h-12 w-20 rounded-md" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-5 w-40" />
                <Skeleton className="h-4 w-60" />
              </div>
            </div>
          </CardHeader>
        </Card>
      ))}
    </div>
  );
}

export default function PrototypeBuilderPage() {
  const params = useParams<{ id: string }>();
  const prototypeId = params.id;

  const { data: prototype, isLoading: prototypeLoading } = useQuery<Prototype>({
    queryKey: ["/api/prototypes", prototypeId],
    enabled: !!prototypeId,
  });

  const { data: screens, isLoading: screensLoading } = useQuery<ScreenWithVariants[]>({
    queryKey: ["/api/prototypes", prototypeId, "screens"],
    enabled: !!prototypeId,
  });

  const enabledScreensCount = screens?.filter(s => s.isEnabled).length || 0;
  const totalVariantsCount = screens?.reduce((sum, s) => sum + (s.variants?.length || 0), 0) || 0;

  if (prototypeLoading) {
    return (
      <div className="flex-1 p-8">
        <Skeleton className="h-8 w-64 mb-2" />
        <Skeleton className="h-4 w-96" />
      </div>
    );
  }

  if (!prototype) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Prototype not found</h2>
          <p className="text-muted-foreground mb-4">The prototype you're looking for doesn't exist.</p>
          <Link href="/">
            <Button>Back to Prototypes</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="border-b bg-card">
        <div className="container max-w-5xl py-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon" data-testid="button-back">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-semibold" data-testid="text-prototype-name">
                  {prototype.name}
                </h1>
                <p className="text-sm text-muted-foreground">
                  {prototype.clientName && `${prototype.clientName} • `}
                  {enabledScreensCount} screens active • {totalVariantsCount} variants
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link href={`/prototype/${prototypeId}/preview`}>
                <Button className="gap-2" data-testid="button-present">
                  <Play className="h-4 w-4" />
                  Present
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="container max-w-5xl py-6">
          <div className="flex items-center justify-between mb-6 flex-wrap gap-2">
            <div>
              <h2 className="text-lg font-semibold">Screens</h2>
              <p className="text-sm text-muted-foreground">
                Upload Figma exports and organize your demo screens
              </p>
            </div>
            <AddScreenDialog 
              prototypeId={prototypeId} 
              onSuccess={() => {}} 
            />
          </div>

          {screensLoading ? (
            <ScreensSkeleton />
          ) : screens && screens.length > 0 ? (
            <div className="space-y-3">
              {screens.map((screen) => (
                <ScreenCard 
                  key={screen.id} 
                  screen={screen} 
                  prototypeId={prototypeId}
                  allScreens={screens}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted mb-4">
                  <Layers className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="font-medium mb-1">No screens yet</h3>
                <p className="text-sm text-muted-foreground text-center max-w-sm mb-4">
                  Upload your Figma design exports to build your interactive prototype. 
                  Each screen can have multiple variants for different demo scenarios.
                </p>
                <AddScreenDialog 
                  prototypeId={prototypeId} 
                  onSuccess={() => {}} 
                />
              </CardContent>
            </Card>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
