import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Plus, Presentation, Building2, Calendar, MoreHorizontal, Play, Pencil, Trash2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { Prototype } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

function PrototypeCard({ prototype }: { prototype: Prototype }) {
  const { toast } = useToast();
  
  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/prototypes/${prototype.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes"] });
      toast({
        title: "Prototype deleted",
        description: "The prototype has been removed successfully.",
      });
    },
  });

  const statusColors: Record<string, string> = {
    draft: "bg-muted text-muted-foreground",
    active: "bg-green-500/10 text-green-600 dark:text-green-400",
    archived: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
  };

  return (
    <Card className="group hover-elevate transition-all duration-200" data-testid={`card-prototype-${prototype.id}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0">
        <div className="flex-1 space-y-1">
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg">{prototype.name}</CardTitle>
            <Badge 
              variant="secondary" 
              className={statusColors[prototype.status] || statusColors.draft}
            >
              {prototype.status}
            </Badge>
          </div>
          <CardDescription className="line-clamp-2">
            {prototype.description || "No description provided"}
          </CardDescription>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity" data-testid={`button-menu-${prototype.id}`}>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <Link href={`/prototype/${prototype.id}/preview`}>
              <DropdownMenuItem data-testid={`menu-preview-${prototype.id}`}>
                <Play className="h-4 w-4 mr-2" />
                Present
              </DropdownMenuItem>
            </Link>
            <Link href={`/prototype/${prototype.id}`}>
              <DropdownMenuItem data-testid={`menu-edit-${prototype.id}`}>
                <Pencil className="h-4 w-4 mr-2" />
                Edit
              </DropdownMenuItem>
            </Link>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              className="text-destructive focus:text-destructive"
              onClick={() => deleteMutation.mutate()}
              data-testid={`menu-delete-${prototype.id}`}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          {prototype.clientName && (
            <div className="flex items-center gap-1.5">
              <Building2 className="h-3.5 w-3.5" />
              <span>{prototype.clientName}</span>
            </div>
          )}
          {prototype.industry && (
            <Badge variant="outline" className="text-xs">
              {prototype.industry}
            </Badge>
          )}
          {prototype.createdAt && (
            <div className="flex items-center gap-1.5 ml-auto">
              <Calendar className="h-3.5 w-3.5" />
              <span>{new Date(prototype.createdAt).toLocaleDateString()}</span>
            </div>
          )}
        </div>
        <div className="mt-4 flex gap-2">
          <Link href={`/prototype/${prototype.id}`} className="flex-1">
            <Button variant="secondary" className="w-full" data-testid={`button-edit-${prototype.id}`}>
              <Pencil className="h-4 w-4 mr-2" />
              Configure
            </Button>
          </Link>
          <Link href={`/prototype/${prototype.id}/preview`}>
            <Button data-testid={`button-preview-${prototype.id}`}>
              <Play className="h-4 w-4 mr-2" />
              Present
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

function PrototypeCardSkeleton() {
  return (
    <Card>
      <CardHeader className="space-y-2">
        <Skeleton className="h-6 w-3/4" />
        <Skeleton className="h-4 w-full" />
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-5 w-16" />
        </div>
        <div className="mt-4 flex gap-2">
          <Skeleton className="h-9 flex-1" />
          <Skeleton className="h-9 w-24" />
        </div>
      </CardContent>
    </Card>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 mb-6">
        <Presentation className="h-8 w-8 text-primary" />
      </div>
      <h3 className="text-xl font-semibold mb-2">No prototypes yet</h3>
      <p className="text-muted-foreground max-w-md mb-6">
        Create your first interactive prototype to start presenting 
        configurable demos to your enterprise clients.
      </p>
      <Link href="/new">
        <Button className="gap-2" data-testid="button-create-first">
          <Plus className="h-4 w-4" />
          Create Your First Prototype
        </Button>
      </Link>
    </div>
  );
}

export default function PrototypesPage() {
  const { data: prototypes, isLoading } = useQuery<Prototype[]>({
    queryKey: ["/api/prototypes"],
  });

  return (
    <div className="flex-1 overflow-auto">
      <div className="container max-w-6xl py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight" data-testid="text-page-title">
              Prototypes
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage your interactive product demos and presentations
            </p>
          </div>
          <Link href="/new">
            <Button className="gap-2" data-testid="button-new-prototype-header">
              <Plus className="h-4 w-4" />
              New Prototype
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <PrototypeCardSkeleton key={i} />
            ))}
          </div>
        ) : prototypes && prototypes.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {prototypes.map((prototype) => (
              <PrototypeCard key={prototype.id} prototype={prototype} />
            ))}
          </div>
        ) : (
          <EmptyState />
        )}
      </div>
    </div>
  );
}
