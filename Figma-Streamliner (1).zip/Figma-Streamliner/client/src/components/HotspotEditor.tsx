import { useState, useRef, useCallback, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Plus, Trash2, MousePointer2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Hotspot, Screen } from "@shared/schema";

interface HotspotEditorProps {
  screenId: string;
  prototypeId: string;
  imageUrl: string;
  hotspots: Hotspot[];
  allScreens: Screen[];
}

interface DrawingRect {
  startX: number;
  startY: number;
  endX: number;
  endY: number;
}

export function HotspotEditor({ 
  screenId, 
  prototypeId, 
  imageUrl, 
  hotspots, 
  allScreens 
}: HotspotEditorProps) {
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawingRect, setDrawingRect] = useState<DrawingRect | null>(null);
  const [selectedHotspot, setSelectedHotspot] = useState<string | null>(null);
  const [isAddMode, setIsAddMode] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const otherScreens = allScreens.filter(s => s.id !== screenId);

  const createHotspotMutation = useMutation({
    mutationFn: async (data: { x: number; y: number; width: number; height: number; targetScreenId: string }) => {
      await apiRequest("POST", "/api/hotspots", {
        screenId,
        ...data,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
      toast({ title: "Hotspot created" });
      setIsAddMode(false);
    },
  });

  const updateHotspotMutation = useMutation({
    mutationFn: async ({ id, targetScreenId }: { id: string; targetScreenId: string }) => {
      await apiRequest("PATCH", `/api/hotspots/${id}`, { targetScreenId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
    },
  });

  const deleteHotspotMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/hotspots/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prototypes", prototypeId, "screens"] });
      toast({ title: "Hotspot deleted" });
      setSelectedHotspot(null);
    },
  });

  const getRelativeCoords = useCallback((e: React.MouseEvent) => {
    if (!containerRef.current) return { x: 0, y: 0 };
    const rect = containerRef.current.getBoundingClientRect();
    return {
      x: Math.round(((e.clientX - rect.left) / rect.width) * 100),
      y: Math.round(((e.clientY - rect.top) / rect.height) * 100),
    };
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (!isAddMode) return;
    e.preventDefault();
    const coords = getRelativeCoords(e);
    setIsDrawing(true);
    setDrawingRect({
      startX: coords.x,
      startY: coords.y,
      endX: coords.x,
      endY: coords.y,
    });
  }, [isAddMode, getRelativeCoords]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDrawing || !drawingRect) return;
    const coords = getRelativeCoords(e);
    setDrawingRect(prev => prev ? { ...prev, endX: coords.x, endY: coords.y } : null);
  }, [isDrawing, drawingRect, getRelativeCoords]);

  const handleMouseUp = useCallback(() => {
    if (!isDrawing || !drawingRect) return;
    setIsDrawing(false);
    
    const x = Math.min(drawingRect.startX, drawingRect.endX);
    const y = Math.min(drawingRect.startY, drawingRect.endY);
    const width = Math.abs(drawingRect.endX - drawingRect.startX);
    const height = Math.abs(drawingRect.endY - drawingRect.startY);
    
    if (width > 2 && height > 2 && otherScreens.length > 0) {
      createHotspotMutation.mutate({
        x,
        y,
        width,
        height,
        targetScreenId: otherScreens[0].id,
      });
    }
    setDrawingRect(null);
  }, [isDrawing, drawingRect, otherScreens, createHotspotMutation]);

  const getTargetScreenName = (targetId: string) => {
    const screen = allScreens.find(s => s.id === targetId);
    return screen?.name || "Unknown";
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium flex items-center gap-2">
          <MousePointer2 className="h-4 w-4" />
          Hotspots ({hotspots.length})
        </h4>
        <Button
          variant={isAddMode ? "default" : "outline"}
          size="sm"
          onClick={() => setIsAddMode(!isAddMode)}
          disabled={otherScreens.length === 0}
          data-testid={`button-add-hotspot-${screenId}`}
        >
          <Plus className="h-3 w-3" />
          {isAddMode ? "Drawing..." : "Add Hotspot"}
        </Button>
      </div>
      
      {otherScreens.length === 0 && (
        <p className="text-xs text-muted-foreground">Add more screens to create hotspots</p>
      )}

      <div 
        ref={containerRef}
        className={`relative border rounded-md overflow-hidden ${isAddMode ? "cursor-crosshair" : ""}`}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={() => {
          if (isDrawing) {
            setIsDrawing(false);
            setDrawingRect(null);
          }
        }}
      >
        <img 
          src={imageUrl} 
          alt="Screen" 
          className="w-full h-auto pointer-events-none select-none"
          draggable={false}
        />
        
        {hotspots.map((hotspot) => (
          <div
            key={hotspot.id}
            className={`absolute border-2 rounded transition-colors cursor-pointer ${
              selectedHotspot === hotspot.id 
                ? "border-primary bg-primary/20" 
                : "border-primary/60 bg-primary/10 hover:bg-primary/20"
            }`}
            style={{
              left: `${hotspot.x}%`,
              top: `${hotspot.y}%`,
              width: `${hotspot.width}%`,
              height: `${hotspot.height}%`,
            }}
            onClick={(e) => {
              e.stopPropagation();
              setSelectedHotspot(selectedHotspot === hotspot.id ? null : hotspot.id);
            }}
            data-testid={`hotspot-${hotspot.id}`}
          >
            <div className="absolute -top-5 left-0 text-xs bg-primary text-primary-foreground px-1.5 py-0.5 rounded whitespace-nowrap">
              → {getTargetScreenName(hotspot.targetScreenId)}
            </div>
          </div>
        ))}

        {drawingRect && (
          <div
            className="absolute border-2 border-dashed border-primary bg-primary/20"
            style={{
              left: `${Math.min(drawingRect.startX, drawingRect.endX)}%`,
              top: `${Math.min(drawingRect.startY, drawingRect.endY)}%`,
              width: `${Math.abs(drawingRect.endX - drawingRect.startX)}%`,
              height: `${Math.abs(drawingRect.endY - drawingRect.startY)}%`,
            }}
          />
        )}
      </div>

      {selectedHotspot && (
        <div className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
          <span className="text-xs text-muted-foreground">Links to:</span>
          <Select
            value={hotspots.find(h => h.id === selectedHotspot)?.targetScreenId}
            onValueChange={(value) => {
              updateHotspotMutation.mutate({ id: selectedHotspot, targetScreenId: value });
            }}
          >
            <SelectTrigger className="flex-1" data-testid={`select-target-${selectedHotspot}`}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {otherScreens.map((screen) => (
                <SelectItem key={screen.id} value={screen.id} data-testid={`option-screen-${screen.id}`}>
                  {screen.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => deleteHotspotMutation.mutate(selectedHotspot)}
            data-testid={`button-delete-hotspot-${selectedHotspot}`}
          >
            <Trash2 className="h-3.5 w-3.5 text-destructive" />
          </Button>
        </div>
      )}

      {hotspots.length > 0 && !selectedHotspot && (
        <p className="text-xs text-muted-foreground">Click a hotspot to edit or delete it</p>
      )}
    </div>
  );
}

interface HotspotOverlayProps {
  hotspots: Hotspot[];
  onHotspotClick: (targetScreenId: string) => void;
  showLabels?: boolean;
  allScreens?: Screen[];
}

export function HotspotOverlay({ hotspots, onHotspotClick, showLabels = false, allScreens = [] }: HotspotOverlayProps) {
  const getTargetScreenName = (targetId: string) => {
    const screen = allScreens.find(s => s.id === targetId);
    return screen?.name || "Unknown";
  };

  return (
    <>
      {hotspots.map((hotspot) => (
        <button
          key={hotspot.id}
          className="absolute border-2 border-transparent hover:border-primary/60 hover:bg-primary/10 rounded transition-all cursor-pointer"
          style={{
            left: `${hotspot.x}%`,
            top: `${hotspot.y}%`,
            width: `${hotspot.width}%`,
            height: `${hotspot.height}%`,
          }}
          onClick={() => onHotspotClick(hotspot.targetScreenId)}
          data-testid={`clickable-hotspot-${hotspot.id}`}
        >
          {showLabels && (
            <div className="absolute -top-5 left-0 text-xs bg-primary text-primary-foreground px-1.5 py-0.5 rounded whitespace-nowrap opacity-0 hover:opacity-100 transition-opacity">
              → {getTargetScreenName(hotspot.targetScreenId)}
            </div>
          )}
        </button>
      ))}
    </>
  );
}
